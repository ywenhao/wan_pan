<?php defined('IN_IA') or exit('Access Denied');?><?php  $_W['page']['title'] = $yunma['name']?>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?>
  <script>
  $(function(){
$('#slide1').swipeSlide({
autoSwipe:true,//自动切换默认是
speed:3000,//速度默认4000
continuousScroll:true,//默认否
transitionType:'cubic-bezier(0.22, 0.69, 0.72, 0.88)',//过渡动画linear/ease/ease-in/ease-out/ease-in-out/cubic-bezier
lazyLoad:true,//懒加载默认否
firstCallback : function(i,sum,me){
            me.find('.dot').children().first().addClass('cur');
        },
        callback : function(i,sum,me){
            me.find('.dot').children().eq(i).addClass('cur').siblings().removeClass('cur');
        }
});

$('#slide2').swipeSlide({
autoSwipe:true,//自动切换默认是
speed:3000,//速度默认4000
continuousScroll:true,//默认否
transitionType:'cubic-bezier(0.22, 0.69, 0.72, 0.88)',//过渡动画linear/ease/ease-in/ease-out/ease-in-out/cubic-bezier
lazyLoad:true,//懒加载默认否
firstCallback : function(i,sum,me){
            me.find('.dot').children().first().addClass('cur');
        },
        callback : function(i,sum,me){
            me.find('.dot').children().eq(i).addClass('cur').siblings().removeClass('cur');
        }
});
$('#slide3').swipeSlide({
autoSwipe:true,//自动切换默认是
speed:3000,//速度默认4000
continuousScroll:true,//默认否
transitionType:'ease-in'
});

	  
	  });    
      
      </script>
<div class="slide" id="slide2">
    <ul>
        <li>
            <a href="#">
                <img src="<?php  echo $_W['attachurl'].$yunma['logo1']?>" data-src="<?php  echo $_W['attachurl'].$yunma['logo1']?>" alt="">
            </a>
           
        </li>
        <li>
            <a href="#">
                <img src="<?php  echo $_W['attachurl'].$yunma['logo2']?>" data-src="<?php  echo $_W['attachurl'].$yunma['logo2']?>" alt="">
            </a>
            
        </li>
        <li>
            <a href="#">
                <img src="<?php  echo $_W['attachurl'].$yunma['logo3']?>" data-src="<?php  echo $_W['attachurl'].$yunma['logo3']?>" alt="">
            </a>
            
        </li>
    </ul>
 <div class="dot">
        <span></span>
        <span></span>
        <span></span>
    </div>
</div>

<div class="page-bd-15">
<div class="center">
<!-- 按钮S-->
  <div class="weui_btn_area weui_btn_area_inline">
        <a href="<?php  echo url('user/login');?>"  class="weui_btn bg-blue-b">用户登录</a><a href="<?php  echo url('user/register');?>" class="weui_btn bg-orange-b">用户注册</a>
  </div>
<!-- 按钮E-->
         <script>
</script>
<!-- 说明S-->
 <div class="weui_cells weui_cells_form">
            <div class="weui_cell">
   
                <div class="weui_cell_bd weui_cell_primary" >
<?php  echo $yunma['ex'];?>
                </div>
         </div>
  </div>

<!-- 说明E-->

<!-- 列表S-->
    <div class="weui_panel_bd">
                <span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title1_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title1_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title1_ex'];?></p>
                    </div>
                </span>
                <span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title2_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title2_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title2_ex'];?></p>
                    </div>
                </span>

        <span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title3_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title3_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title3_ex'];?></p>
                    </div>
                </span>

                        <!--span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title4_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title4_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title4_ex'];?></p>
                    </div>
                </span-->
<!-- 列表E-->

            </div>

  </div>  
  </div> 
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/footer-yunma', TEMPLATE_INCLUDEPATH));?>