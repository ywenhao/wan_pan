<?php defined('IN_IA') or exit('Access Denied');?><div style="margin-top: 20px;">
<div class="weui-footer">
            <p class="weui-footer-links">
                <a href="http://55581.com" class="weui-footer-link">幸运彩票</a>
                <a href="http://55581.com" class="weui-footer-link">幸运棋牌</a>
                <a href="http://www.18845.cn" class="weui-footer-link">幸运防封</a>
                <a href="http://dwh.com" class="weui-footer-link">幸运码云</a>
            </p>
            <p class="weui-footer-text">小幸运Copyright &copy; 2019</p>


</div>
</body>
</html>
