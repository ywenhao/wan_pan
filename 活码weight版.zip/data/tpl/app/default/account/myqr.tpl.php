<?php defined('IN_IA') or exit('Access Denied');?>
 <?php  $_W['page']['title'] = '活码列表'?> <?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?> 

 <style type="text/css">
.table{width:100%;border-collapse:collapse;background-color:#fff;line-height:32px;text-align:center}.table td,.table th{border-right:1px solid #e0e0e0;text-align:center;font-weight:500}
 </style>

  <div class="weui-gallery" id="gallery" align="center">
            <img class="weui-gallery__img" id="galleryImg" style="height:100%;">
 </div>

  <div class="center" id="imgFile"> 


   <div class="weui_btn_default weui-header weui_btn_plain_primary"> 
    <div class="weui-header-left"> 
     <a class="icon icon-109 f-green" href="javascript:history.go(-1)">返回</a>
    </div> 
    <h1 class="weui-header-title f-green">创建活码</h1> 
   </div> 
   <div class="weui_cells weui_cells_form"> 
    <div class="weui_cell"> 
     <div class="weui_cell_bd weui_cell_primary" align="center"> 
      <span class="icon icon-100"></span><?php  echo $member['username'];?>
     </div> 
    </div> 
   </div> 
   <div  align="center">
     <div class="weui_cells weui_cells_form" style="width: 70%"> 
    <a href="<?php  echo url('account/createqr');?>" class="weui_btn bg-orange">创建活码</a>
</div>
</div>

<?php  if(!empty($qrList)) { ?>
<?php  if(is_array($qrList)) { foreach($qrList as $qrList) { ?>

 <div class="weui_panel weui_panel_access" id="List<?php  echo $qrList['id'];?>">
            <div class="weui_panel_hd" style="color: #000;font-size: 18px;" id="Name<?php  echo $qrList['id'];?>"><?php  echo $qrList['name'];?></div>
            <div class="weui_panel_bd">
                <span class="weui_media_box weui_media_appmsg">
                 
                    <div class="table" align="center">
						<table class="table">
               				 <tbody>
               					 <tr>
               					 <td style="width: 30%;height: 100%" id="imgFile">   
     <img class="weui_media_appmsg_thumb" style="width:60px;height:60px;line-height:60px;"" src="<?php  echo $qrList['qrimg'];?>" alt="">
                    			</td>
                    <td style="width: 40%">
     <h4>图片：<span class="f-green"><?php  echo mc_getImgCount($qrList['sid'])?>张</span></h4>
     <h4>阀值：<span class="f-zi"><?php  echo $qrList['fazhi'];?>次</span></h4>

                    </td>
     <td style="width: 30%;border-right:0px solid #e0e0e0;">扫描总数<h4 class="f-blue"><?php  echo $qrList['count'];?>次</h4></td>
                    </tr>

                </tbody>
            </table>
                    </div>
                </span>

<div  class="weui_media_box weui_media_appmsg weui_btn_area weui_btn_area_inline">
           <a href="<?php  echo url('account/edit_qr',array('sid'=>$qrList['sid']));?>" class="weui_btn weui_btn_plain_primary">编辑</a>
          <a href="javascript:;" class="weui_btn weui_btn_plain_red" onclick="del(<?php  echo $qrList['id'];?>)">删除</a>
</div></div></div>

<?php  } } ?>
<?php  } else { ?>
<div align="center">
   <div style="margin-top:88px;"></div> 
   <p class="f-blue" style="font-weight: bold;">赶紧生成属于你自己的二维活码吧！</p>
   <p class="f-blue" style="font-weight: bold;">别犹豫了赶紧创建吧</p>
</div>
<?php  } ?>       

   <div style="margin-top:88px;"></div> 

  <section class="weui-menu">
      <a class="weui-menu-inner" href="<?php  echo url('account/index');?>">
     <span class="icon icon-27"></span> 
     <span>首页</span> 
       </a> 
    <a class="weui-menu-inner" href="<?php  echo url('account/myqr');?>" style="color:orange">
   <span class="icon icon-25"></span> 
     <span>活码</span> 
       </a>
    <a class="weui-menu-inner" href="<?php  echo url('account/member');?>"> 
     <span class="icon icon-99"></span> 
     <span>我的</span> 
    </a> 
   </section> 
</div> 

<script type="text/javascript">
    $(function(){
        var $gallery = $("#gallery"), $galleryImg = $("#galleryImg"),
            $uploaderInput = $("#uploaderInput"),
            $imgFile = $("#imgFile");


 $imgFile.on("click", "img", function(){
            $galleryImg.attr("src", this.getAttribute("src"));
            $gallery.fadeIn(100);
        });
        $gallery.on("click", function(){
            $gallery.fadeOut(100);
        });
    });

$(".userImg").each(function(){
    $(this).click(function(){
         var imgid = $(this).attr("id");
         alert(imgid );
    })
    });

//用户删除
function del(Num) {
	 $.confirm("您确定要删除『"+$("#Name"+Num).text()+"』吗?", "确认删除?", function() {
        $.showLoading();

  $.post("<?php  echo url('account/myqr/',array('op'=>'del'));?>", {'qrId':Num}, function(data){
        info = eval(data);
        if(info.s=="ok"){
           $.hideLoading();//加载中
          $("#List"+Num).remove()
          $.toast("删除成功");//提示删除
        }else{
           $.hideLoading();//加载中
           $.toast("删除失败", "forbidden");
        }
  },'json')


 		     	
        });
}

</script>


  </div>   
 </body>
</html>