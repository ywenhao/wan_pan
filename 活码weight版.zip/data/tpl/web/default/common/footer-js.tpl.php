<?php defined('IN_IA') or exit('Access Denied');?>    <script type="text/javascript" src="./resource/wynters/js/jquery.min.js?v=2.1.4"></script>
    <script type="text/javascript" src="./resource/wynters/js/bootstrap.min.js?v=3.3.5"></script>
    <script type="text/javascript" src="./resource/wynters/js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script type="text/javascript" src="./resource/wynters/js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script type="text/javascript" src="./resource/wynters/js/plugins/layer/layer.min.js"></script>
    <script type="text/javascript" src="./resource/wynters/js/hplus.min.js?v=4.0.0"></script>
    <script type="text/javascript" src="./resource/wynters/js/contabs.min.js"></script>
    <script type="text/javascript" src="./resource/wynters/js/plugins/pace/pace.min.js"></script>
    <script src="./resource/wynters/js/plugins/flot/jquery.flot.js"></script>
    <script src="./resource/wynters/js/plugins/flot/jquery.flot.tooltip.min.js"></script>
    <script src="./resource/wynters/js/plugins/flot/jquery.flot.spline.js"></script>
    <script src="./resource/wynters/js/plugins/flot/jquery.flot.resize.js"></script>
    <script src="./resource/wynters/js/plugins/flot/jquery.flot.pie.js"></script>
    <script src="./resource/wynters/js/plugins/peity/jquery.peity.min.js"></script>
    <script src="./resource/wynters/js/demo/peity-demo.min.js"></script>
    <script src="./resource/wynters/js/content.min.js?v=1.0.0"></script>
    <script src="./resource/wynters/js/plugins/jquery-ui/jquery-ui.min.js"></script>
    <script src="./resource/wynters/js/plugins/gritter/jquery.gritter.min.js"></script>
    <script src="./resource/wynters/js/plugins/easypiechart/jquery.easypiechart.js"></script>
    <script src="./resource/wynters/js/plugins/sparkline/jquery.sparkline.min.js"></script>
    <script src="./resource/wynters/js/demo/sparkline-demo.min.js"></script>
    <script type="text/javascript" src="./resource/js/require.js?v=20170209"></script>
    <script type="text/javascript" src="./resource/js/app/config.js?v=20170209"></script>