<?php
/**
 * 主页
 */
defined('IN_IA') or exit('Access Denied');
define('IN_GW', true);

$member = $_W['user'];
template('account/welcome');
