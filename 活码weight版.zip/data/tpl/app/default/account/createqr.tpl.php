<?php defined('IN_IA') or exit('Access Denied');?><?php  $_W['page']['title'] = '创建活码'?> <?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?>
<script type="text/javascript" src="<?php  echo $_W['siteroot'];?>app/resource/weui/js/qrcode.min.js"></script>
<script type="text/javascript" src="<?php  echo $_W['siteroot'];?>app/resource/weui/js/lrz.min.js"></script>
<style type="text/css">
  .weui-gallery-opr {
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: #0D0D0D;
    color: #FFFFFF;
    line-height: 60px;
    text-align: center;
  }

  .weui-gallery-del {
    display: block;
  }

  .weui-gallery-img {
    position: absolute;
    top: 0;
    right: 0;
    bottom: 60px;
    left: 0;
    background: center center no-repeat;
    background-size: contain;
  }
</style>
<div class="center">

  <div class="weui-gallery" id="gallery" align="center">
    <img class="weui-gallery__img" id="galleryImg" style="height:100%;">
  </div>

  <div class="weui_btn_default weui-header weui_btn_plain_primary">
    <div class="weui-header-left">
      <a class="icon icon-109 f-green" href="javascript:history.go(-1)">返回</a>
    </div>
    <h1 class="weui-header-title f-green">创建活码</h1>
  </div>
  <div style="margin-top:10px;"></div>
  <div id="qrcode" align="center" style="display: none;"></div>
  <div class="weui_cell_bd weui_cell_primary center" align="center" id="upFile" style="display:none;">
    <div class="weui_uploader" style="width: 80%">
      <div class="weui_uploader_hd weui_cell">
        <div class="weui_panel_hd" id="upQrName">上传二维码&nbsp;&nbsp;</div>
        <div class="weui_cell_ft"></div>
      </div>
      <div class="weui_uploader_bd" align="center">
        <ul class="weui_uploader_files" id="uploaderFiles">
        </ul>
        <div class="weui_uploader_input_wrp">
          <input onchange="previewImage(this)" class="weui_uploader_input" type="file"
            accept="image/jpg,image/jpeg,image/png" multiple>

        </div>
      </div>
    </div>
    <a href="javascript:;" class="weui_btn bg-blue-b" style="width: 80%">保存二维码</a>
  </div>

  <input id="codeId" type="hidden" />
  <div align="center" id="createQr">
    <div class="weui_cells weui_cells_form" style="width: 80%">
      <div class="weui_cell">
        <div class="weui_cell_hd"><label class="weui_label">名称</label></div>
        <div class="weui_cell_bd weui_cell_primary">
          <input class="weui_input" id="Name" type="text" placeholder="名称" />
        </div>
      </div>

      <div class="weui_cell">
        <div class="weui_cell_hd"><label class="weui_label">阀值</label></div>
        <div class="weui_cell_bd weui_cell_primary">
          <input class="weui_input" id="FaZhi" pattern="[0-9]*" maxlength="5" type="number" placeholder="阀值" />
        </div>
      </div>
    </div><br />
    <div style="width: 80%">
      <a href="javascript:;" class="weui_btn bg-orange" id='qr'>生成活码</a>
      <a class="weui_btn bg-blue" id="Edit" style="display: none;width: 100%">编辑活码</a>
    </div>

  </div>


  <div style="margin-top:88px;"></div>

  <section class="weui-menu">
    <a class="weui-menu-inner" href="<?php  echo url('account/index');?>">
      <span class="icon icon-27"></span>
      <span>首页</span>
    </a>
    <a class="weui-menu-inner" href="<?php  echo url('account/myqr');?>" style="color:orange">
      <span class="icon icon-25"></span>
      <span>活码</span>
    </a>
    <a class="weui-menu-inner" href="<?php  echo url('account/member');?>">
      <span class="icon icon-99"></span>
      <span>我的</span>
    </a>
  </section>

</div>



<script type="text/javascript">
  var info;
  $("#qr").click(function () {

    if (_CheckEx()) {
      $.showLoading('生成中...');

      var qrcode = $("#qrcode").html(); //获取内容

      mydata = {
        'userId': $('#userId').val(),
      };
      if (qrcode == "") {

        $.post("<?php  echo url('account/createqr',array('op'=>'qr'));?>", mydata, function (data) {
          info = eval(data);
          new QRCode(document.getElementById('qrcode'), "<?php  echo $_W['siteroot'];?><?php  echo url('account/qr');?>sid=" + info.msg);
          $('#codeId').val(info.msg);
          $.hideLoading();
          $.toast("生成成功");
          $("#qrcode").slideDown(2000);
          $("#qr").text("重新生成");
          $("#Edit").slideDown(3000);
        }, 'json')

        qrCodeInfo = getQrInfo();

      } else {

        $.post("<?php  echo url('account/createqr/',array('op'=>'qr'));?>", mydata, function (data) {
          info = eval(data);
          $('#qrcode').empty();
          $('#qrcode').hide();
          new QRCode(document.getElementById('qrcode'), '' + info.msg);
          $.hideLoading();
          $.toast("生成成功");
          $("#qr").text("重新生成");
          $("#qrcode").slideDown(2000);
          $("#qr").text("重新生成");
          $("#Edit").show(3000);
        }, 'json')

      }
    }

  });

  $("#Edit").click(function () {
    $.confirm("您确定要使用『" + $('#Name').val() + "』二维码吗？", "确认使用?", function () {
      if (_CheckEx()) {
        $("#createQr").slideUp(1500);
        $("#upQrName").append("名称『" + $('#Name').val() + "』阀值【" + $('#FaZhi').val() + "】")
        $("#upFile").slideDown(3500);
      }
    }, function () {
      //取消操作
    });
  });

  $(function () {
    var $gallery = $("#gallery"), $galleryImg = $("#galleryImg"),
      $uploaderInput = $("#uploaderInput"),
      $uploaderFiles = $("#uploaderFiles");

    $uploaderFiles.on("click", "li", function () {
      $galleryImg.attr("src", this.getAttribute("img-data"));
      $gallery.fadeIn(100);
    });
    $gallery.on("click", function () {
      $gallery.fadeOut(100);
    });
  });


  function _CheckEx() {
    if ($('#Name').val() == "") {
      $.prompt("请输入活码名称", "码名未输入", function (text) {
        $('#Name').val(text);
      }, function () {
        $.toast("请输入活码名称", "forbidden");
      });
      return false;
    } if ($('#FaZhi').val() == "") {
      $.prompt("请输入阀值", "阀值未输入", function (text) {
        $('#FaZhi').val(text);
      }, function () {
        $.toast("请输入阀值", "forbidden");
      });
      return false;
    } if ($('#FaZhi').val() > 200) {
      $.prompt("阀值最大不得超过200,请重新输入", "阀值溢出", function (text) {
        $('#FaZhi').val(text);
      }, function () {
        $.toast("阀值溢出", "forbidden");
        $('#FaZhi').val("");
      });
      return false;
    }
    return true;
  }

  $(".bg-blue-b").click(function () {

    if (_CheckEx()) {
      var imgs = $('#uploaderFiles li');
      var qrCode = $('#qrcode img');
      var imgData = new Array();
      var nameData = new Array();
      for (var i = 0; i < imgs.length; i++) {
        imgData[i] = imgs[i].getAttribute('img-data');
        nameData[i] = imgs[i].getAttribute('name-data');
      }
      $.showLoading("保存中...");
      if (qrCode[0].getAttribute('src') == '') {
        $.hideLoading();//加载中
        $.toast('活码获取失败', "forbidden");
        return false;
      } if (imgData == '') {
        $.hideLoading();//加载中
        $.toast('请上传至少一张二维码', "forbidden");
        return false;
      }


      $.post("<?php  echo url('account/upfile',array('op'=>'create'));?>", { 'codeId': $('#codeId').val(), 'Name': $('#Name').val(), 'FaZhi': $('#FaZhi').val(), 'qrCode': qrCode[0].getAttribute('src'), 'imgdata': imgData, 'namedata': nameData }, function (data) {
        info = eval(data);
        if (info.s == "ok") {
          $.hideLoading();//加载中

          $.confirm("接下来你可以编辑了", "保存成功", function () {
            location.href = './index.php?c=account&a=edit_qr&sid=' + $('#codeId').val();
          }, function () {
            location.href = './index.php?c=account&a=myqr&';
          })
        } else {
          $.hideLoading();//加载中
          $.toast(info.msg, "forbidden");
        }


      }, 'json')
    }
  })

  function previewImage(file) {

    var MAXWIDTH = 100;
    var MAXHEIGHT = 200;

    var tmpl = '<li class="weui_uploader_file" style="background-image:url(#url#)" img-data="#url#" name-data="#img_name#"></li>';

    if (file.files.length > 0) {
      var tempFileName;
      var flagLength = 0;
      var reader = new FileReader();
      if (file.files && file.files[flagLength]) {
        reader.readAsDataURL(file.files[flagLength]);
        reader.onload = function (evt) {
          tempFileName = file.files[flagLength].name.slice(0, file.files[flagLength].name.lastIndexOf("."));
          if (evt.target.result) {
            $('#uploaderFiles').append($(tmpl.replace(/#url#/g, evt.target.result).replace(/#img_name#/, tempFileName)));
          }
          flagLength++;
          if (flagLength < file.files.length) {
            reader.readAsDataURL(file.files[flagLength]);//读取文件 再次调用onload
          }
        }
      }
    }
  }
</script>
</body>

</html>