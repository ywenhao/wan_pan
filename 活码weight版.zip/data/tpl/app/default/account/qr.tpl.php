<?php defined('IN_IA') or exit('Access Denied');?>  <?php  $_W['page']['title'] = '长按识别二维码'?> <?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?> 
<style type="text/css">
.box{opacity:1;width:100%;height:30px;line-height:28px;text-align:center;background-color:#fff;border-radius:0.2em}
</style>
<div class="box">
<span class="weui_icon_safe_success"><span class="f-green">图片已通过微信团队安全认证</span></span>
</div>
 <div style="width: 100%;height: 100%;" align="center">
    <img style="width: 100%"  src="<?php  echo $img;?>" />
</div>
</body>
</html>