<?php defined('IN_IA') or exit('Access Denied');?>			</div>
		</div>
		<div class="center-block footer" role="footer">
			
		</div>
	</div>
			<?php  if(!empty($_W['setting']['copyright']['statcode'])) { ?><?php  echo $_W['setting']['copyright']['statcode'];?><?php  } ?>

</body>
</html>
