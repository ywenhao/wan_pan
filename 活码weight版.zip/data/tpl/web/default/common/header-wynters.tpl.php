<?php defined('IN_IA') or exit('Access Denied');?><!DOCTYPE html>
<html lang="zh-cn">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title><?php  echo $_W['page']['title'];?></title>
	<link href="./resource/wynters/css/bootstrap.min.css" rel="stylesheet">
	<link href="./resource/wynters/css/font-awesome.min.css" rel="stylesheet">
	<link href="./resource/wynters/css/animate.min.css" rel="stylesheet">
	<link href="./resource/wynters/css/style.min.css" rel="stylesheet">
	<link rel="shortcut icon" href="favicon.ico"> 
	<link href="./resource/wynters/css/bootstrap.min.css?v=3.3.5" rel="stylesheet">
    <link href="./resource/wynters/css/font-awesome.min.css?v=4.4.0" rel="stylesheet">
    <link href="./resource/wynters/css/plugins/morris/morris-0.4.3.min.css" rel="stylesheet">
    <link href="./resource/wynters/js/plugins/gritter/jquery.gritter.css" rel="stylesheet">
    <link href="./resource/wynters/css/animate.min.css" rel="stylesheet">
    <link href="./resource/wynters/css/style.min.css?v=4.0.0" rel="stylesheet">
</head>
