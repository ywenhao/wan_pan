<?php defined('IN_IA') or exit('Access Denied');?>  <?php  $_W['page']['title'] = '个人中心'?> <?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?> 
<style>
.member-top { -webkit-animation:changeBg 20s infinite;top: 10% -moz-animation:changeBg 20s infinite; animation:changeBg 20s infinite;background-color:#ED5564; background-size: cover;  
text-align: center; width: 100%; height: 30%; position: relative; z-index: 1;}
@-webkit-keyframes changeBg{
0%{background-color:#ED5564;}
10%{background-color:#FB6E52;}
20%{background-color:#FFCE55;}
30%{background-color:#A0D468;}
40%{background-color:#48CFAE;}
50%{background-color:#4FC0E8;}
60%{background-color:#ffaaab;}
70%{background-color:#AC92ED;}
80%{background-color:#EC87BF;}
90%{background-color:#ED5564;}
}
@-moz-keyframes changeBg{
0%{background-color:#ED5564;}
10%{background-color:#FB6E52;}
20%{background-color:#FFCE55;}
30%{background-color:#A0D468;}
40%{background-color:#48CFAE;}
50%{background-color:#4FC0E8;}
60%{background-color:#ffaaab;}
70%{background-color:#AC92ED;}
80%{background-color:#EC87BF;}
90%{background-color:#ED5564;}
}
@keyframes changeBg{
0%{background-color:#ED5564;}
10%{background-color:#FB6E52;}
20%{background-color:#FFCE55;}
30%{background-color:#A0D468;}
40%{background-color:#48CFAE;}
50%{background-color:#4FC0E8;}
60%{background-color:#ffaaab;}
70%{background-color:#AC92ED;}
80%{background-color:#EC87BF;}
90%{background-color:#ED5564;}
}
.place{background-color:#ebebeb;text-align:center;color:red;margin:5px;font-weight: bolder;}
.holders{color:#000;font-weight: normal;}
</style>
  <div class="center"> 
   <div class="weui_btn_default weui-header weui_btn_plain_primary"> 
    <div class="weui-header-left"> 
     <a class="icon icon-109 f-green" href="javascript:history.go(-1)">返回</a>
    </div> 
    <h1 class="weui-header-title f-green">首页</h1> 
   </div> 
<div class="member-top">
<div style="width:100%;">
<img src="https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=785610095,2402278722&fm=117&gp=0.jpg" class="circle xz360" style="width:25%;margin-top:3%;" ><br />
<span><?php  echo $member['username'];?></span>
</div></div>
<div class="weui-flex">
            <div class="weui-flex-item"><div class="place"><label class="weui-label-s">SVIP7</label><br /><span class="holders">等级</span></div></div>
            <div class="weui-flex-item"><div class="place">2<br /><span class="holders">活码数量</span></div></div>
            <div class="weui-flex-item"><div class="place">999<br /><span class="holders">累计扫描</span></div></div>
        </div>
<div class="weui_grids"  >
            <a href="javascript:;" class="weui_grid js_grid"  >
                <div class="weui_grid_icon">
                    <img src="./resource/weui/images/icon_nav_button.png" alt="">
                </div>
                <p class="weui_grid_label">
                    修改密码
                </p>
            </a>



        </div>




   <div style="margin-top:88px;"></div> 

  <section class="weui-menu">
      <a class="weui-menu-inner" href="<?php  echo url('account/index');?>">
     <span class="icon icon-27"></span> 
     <span>首页</span> 
       </a> 
    <a class="weui-menu-inner" href="<?php  echo url('account/myqr');?>" >
   <span class="icon icon-25"></span> 
     <span>活码</span> 
       </a>
    <a class="weui-menu-inner" href="javascript:;" style="color:orange"> 
     <span class="icon icon-99"></span> 
     <span>我的</span> 
    </a> 
   </section> 

  </div>   
 </body>
</html>