<?php defined('IN_IA') or exit('Access Denied');?>  <?php  $_W['page']['title'] = '首页'?> <?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?> 
  <div class="center"> 
   <div class="weui_btn_default weui-header weui_btn_plain_primary"> 
    <div class="weui-header-left"> 
     <a class="icon icon-109 f-green" href="javascript:history.go(-1)">返回</a>
    </div> 
    <h1 class="weui-header-title f-green">首页</h1> 
   </div> 
   <div class="weui_cells weui_cells_form"> 
    <div class="weui_cell"> 
     <div class="weui_cell_bd weui_cell_primary" align="center"> 
      <span class="icon icon-100"></span><?php  echo $member['username'];?>
     </div> 
    </div> 
   </div> 
   <div class="weui_btn_area weui_btn_area_inline"> 
    <a href="<?php  echo url('account/createqr');?>" class="weui_btn bg-orange">创建活码</a>
    <a href="<?php  echo url('account/myqr');?>" class="weui_btn bg-blue">活码管理</a> 
   </div> 
	  
<!-- 列表S-->
    <div class="weui_panel_bd">
                <span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title1_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title1_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title1_ex'];?></p>
                    </div>
                </span>
                <span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title2_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title2_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title2_ex'];?></p>
                    </div>
                </span>

        <span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title3_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title3_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title3_ex'];?></p>
                    </div>
                </span>

                        <!--span class="weui_media_box weui_media_appmsg">
                    <div class="weui_media_hd">
                        <img class="weui_media_appmsg_thumb" src="<?php  echo $_W['attachurl'].$yunma['title4_img']?>" alt="">
                    </div>
                    <div class="weui_media_bd">
                        <h4 class="weui_media_title"><?php  echo $yunma['title4_title'];?></h4>
                        <p class="weui_media_desc"><?php  echo $yunma['title4_ex'];?></p>
                    </div>
                </span-->
<!-- 列表E-->

            </div>
	  
   <div class="weui_cells weui_cells_form"> 
    <!--div class="weui_cell"> 
     <div class="weui_cell_bd weui_cell_primary">
<?php  echo $yunma['member_content5'];?>
    </div> 
   </div--> 
   <section class="weui-menu">
    <div class="weui-menu-inner">
     <a href="<?php  echo url('account/index');?>"  style="color:orange">
     <span class="icon icon-27"></span> 
     <span>首页</span> 
       </a> 
    </div>
    <div class="weui-menu-inner"> 
     <a href="<?php  echo url('account/myqr');?>">
   <span class="icon icon-25"></span> 
     <span>活码</span> 
       </a>
    </div> 
    <div class="weui-menu-inner"> 
    <a href="<?php  echo url('account/member');?>">
     <span class="icon icon-99"</span> 
     <span>我的</span> 
      </a>
    </div> 
   </section> 
  </div>   
 </body>
</html>