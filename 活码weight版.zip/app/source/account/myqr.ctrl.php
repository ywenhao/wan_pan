<?php
/**
 * 主页
 */
defined('IN_IA') or exit('Access Denied');
define('IN_GW', true);
$member = $_W['user'];
$op = $_GPC['op'];
$qrList  = mc_getQrList($member[uid]);

if ($op == 'del'){

	if(mc_delQrList(intval($_GPC['qrId']))){
		$response = array('s' => 'ok', 'msg' =>1);
	}else{
		$response = array('s' => 'no', 'msg' =>0);
	}


    echo json_encode($response);
    
}else {
template('account/myqr');
}