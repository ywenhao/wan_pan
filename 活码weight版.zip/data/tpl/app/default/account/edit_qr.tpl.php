<?php defined('IN_IA') or exit('Access Denied');?><?php  $_W['page']['title'] = '创建活码'?> <?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?>
<script type="text/javascript" src="<?php  echo $_W['siteroot'];?>app/resource/weui/js/qrcode.min.js"></script>
<script type="text/javascript" src="<?php  echo $_W['siteroot'];?>app/resource/weui/js/lrz.min.js"></script>
<style type="text/css">
	.weui-gallery-opr {
		position: absolute;
		right: 0;
		bottom: 0;
		left: 0;
		background-color: #0D0D0D;
		color: #FFFFFF;
		line-height: 60px;
		text-align: center;
	}

	.weui-gallery-del {
		display: block;
	}

	.weui-gallery-img {
		position: absolute;
		top: 0;
		right: 0;
		bottom: 60px;
		left: 0;
		background: center center no-repeat;
		background-size: contain;
	}
</style>
<div class="center">

	<div class="weui-gallery" id="gallery" align="center">
		<img class="weui-gallery__img" id="galleryImg" style="height:100%;">
	</div>

	<div class="weui_btn_default weui-header weui_btn_plain_primary">
		<div class="weui-header-left">
			<a class="icon icon-109 f-green" href="javascript:history.go(-1)">返回</a>
		</div>
		<h1 class="weui-header-title f-green">编辑活码</h1>
	</div>
	<div style="margin-top:10px;"></div>
	<div id="qrcode" align="center">
		<img src="<?php  echo $Qr['qrimg'];?>">
	</div>
	<div align="center" id="createQr">
		<div class="weui_cells weui_cells_form" style="width: 80%">
			<div class="weui_cell">
				<input id="codeId" value="<?php  echo $Qr['sid'];?>" type="hidden" />
				<div class="weui_cell_hd"><label class="weui_label">名称</label></div>
				<div class="weui_cell_bd weui_cell_primary">
					<input class="weui_input" id="Name" value="<?php  echo $Qr['name'];?>" type="text" placeholder="名称" />
				</div>
			</div>
			<div class="weui_cell">
				<div class="weui_cell_hd"><label class="weui_label">阀值</label></div>
				<div class="weui_cell_bd weui_cell_primary">
					<input class="weui_input" id="FaZhi" value="<?php  echo $Qr['fazhi'];?>" pattern="[0-9]*" maxlength="5" type="number" placeholder="阀值" />
				</div>
			</div>
		</div><br />
		<div style="width: 90%">
			<div class="weui_cell_bd weui_cell_primary center" align="center" id="upFile">
				<div class="weui_uploader" style="width: 90%">
					<div class="weui_uploader_hd weui_cell">
						<div class="weui_panel_hd" id="upQrName">上传二维码&nbsp;&nbsp;</div>
						<div class="weui_cell_ft"></div>
					</div>
					<div class="weui_uploader_bd" align="center">
						<ul class="weui_uploader_files" id="uploaderFiles">
						</ul>
						<div class="weui_uploader_input_wrp">
							<input onchange="previewImage(this)" class="weui_uploader_input" type="file" accept="image/jpg,image/jpeg,image/png"
							 multiple>

						</div>
					</div>
				</div>
				<a href="javascript:;" class="weui_btn bg-blue-b" style="width: 80%">保存修改信息</a>
			</div>




			<div class="weui_cells weui_cells_form " style="text-align:left;">

				<?php  if(is_array($imgList)) { foreach($imgList as $imgList) { ?>
				<div class="weui_cell" id="imgList<?php  echo $imgList['id'];?>">
					<input type="checkbox" name="" id="" value="<?php  echo $imgList['id'];?>" style="margin-right: 5px;" />
					<div style="width:200px;word-wrap:break-word;word-break:break-all; ">
						<p align="left"><?php  echo $imgList['i_name'];?></p>
					</div>
					<div class="weui_cell_hd" style="margin-left:10px"><img src="<?php  echo $imgList['img'];?>" style="width:50px;margin-right:5px;"></div>
					<div class="weui_cell_bd weui_cell_primary">
						<p align="center"><?php  echo $imgList['count'];?>次</p>
					</div>
					<div style="font-size: 0px;" class="weui_cell_ft">
						<a class="weui-number weui-number-sub needsclick" href="javascript:;" style="width:10px;" onclick="inMinus(<?php  echo $imgList['id'];?>)">-</a>
						<input pattern="[0-9]*" class="weui-number-input" style="width: 30px;font-size: 17px;" id="Num<?php  echo $imgList['id'];?>"" value="<?php  echo $imgList['weight'];?>" data-min="1" data-max="10" data-step="2">
						<a class="weui-number weui-number-plus needsclick" href="javascript:;" style="width:10px;" onclick="inAdd(<?php  echo $imgList['id'];?>)">+</a>
					</div>
					<div class="weui_cell_ft" style="display: none;"> 0 </div><a href="javascript:;" class="weui_btn weui_btn_mini weui_btn_primary bg-blue"
					 onclick="updataImg(<?php  echo $imgList['id'];?>)">确定</a>&nbsp;<span class="delete" onclick="delImg(<?php  echo $imgList['id'];?>)" href="javascript:;"><span
						 class="icon icon-26 f20 f-red"></span></span>
				</div>

				<?php  } } ?>
			</div>





			<!--div class="weui_panel" style="text-align:left;">
            <div class="weui_panel_hd">小图文组合列表</div>
            <div class="weui_panel_bd">
                <div class="weui_media_box weui_media_small_appmsg">
                    <div class="weui_cells weui_cells_access">
                    <?php  if(is_array($imgList)) { foreach($imgList as $imgList) { ?>
                        <span class="weui_cell" href="javascript:;">
                            
                            <div class="weui_cell_bd weui_cell_primary">
                                <p>文字标题</p>
                            </div>

            <a href="javascript:;" style="width: 10%" class="weui_btn bg-orange-b">确定</a>

                        </span>
                        <?php  } } ?>
                    </div>
                </div>
            </div>
        </div>
   </div-->

		</div>
		<div class="weui_cell" style="width: 80%;margin-top:15px;">
			
				<input type="checkbox" name="" id="checkbtn" value="allcheck" />
				<span>全选/反选</span>
				<a href="javascript:;" class="weui_btn bg-red f-while del-btn" style="">批量删除</a>
			
			
				<span style="margin-left:25px">删除 大于等于 </span>
				<input type="number" id="deleg" class="weui-number-input" style="width: 40px;font-size: 17px;"  value="50" min="0">
				<span>次</span>
				<a href="javascript:;" class="weui_btn bg-red f-while del-eg" style="width:100px;left:0px;">确定</a>
			
		</div>
		<div style="margin-top:88px;"></div>

		<section class="weui-menu">
			<a class="weui-menu-inner" href="<?php  echo url('account/index');?>">
				<span class="icon icon-27"></span>
				<span>首页</span>
			</a>
			<a class="weui-menu-inner" href="<?php  echo url('account/myqr');?>" style="color:orange">
				<span class="icon icon-25"></span>
				<span>活码</span>
			</a>
			<a class="weui-menu-inner" href="<?php  echo url('account/member');?>">
				<span class="icon icon-99"></span>
				<span>我的</span>
			</a>
		</section>

	</div>



	<script type="text/javascript">
		$(".del-eg").click(() => {
			$.confirm("您确认要删除吗？","确认删除", function() {
				$.showLoading('删除中...');
				var deleg = $("#deleg").val();
				
				if(deleg){
					$.post("<?php  echo url('account/edit_qr',array('op'=>'deleg'));?>", {
						'sid': $('#codeId').val(),
						'delEg': deleg
					},function(data){
						console.log(data)
						info = eval(data);
						if (info.s == 'ok') {
							$.hideLoading();
							$.toast("删除成功");
							location.href = './index.php?c=account&a=edit_qr&sid=' + $('#codeId').val();
						} else {
							$.hideLoading();
							$.toast("删除失败！", "forbidden");
						}
					},'json')
				}else{
					$.hideLoading();
					$.toast("请输入数字！", "forbidden");
				}
			})
		})
		
		$("#checkbtn").click(() => {

			$(".weui_cells_form input").each((i, v) => {
				if ($("#checkbtn")[0].checked) {
					v.checked = true
				} else {
					v.checked = false
				}
			})
		})
		
		$("a.del-btn").click(() => {
				$.confirm("您确定要删除吗？", "确认批量删除", function() {
					$.showLoading('删除中...');
					var imgId = new Array();
					var img_index = 0;
					$(".weui_cells_form input").each(function(i) {
						if ($(this).is(":checked")) {
							imgId[img_index]=$(this).val()
						img_index++;
						}						
					})
				
					if(imgId.length>0){
						$.post("<?php  echo url('account/edit_qr',array('op'=>'del'));?>", {
							'sid': $('#codeId').val(),
							'imgId': imgId
						},function(data){
							info = eval(data);
							if (info.s == 'ok') {
								$.hideLoading();
								$.toast("删除成功");
								$(imgId).each((i,v)=>{
									$('#imgList' + v).animate({
										'left': -1000
									}, 800);
									$('#imgList' + v).slideUp(200);
									setTimeout(()=>{$('#imgList' + v).remove()},1e3);
								})
								
								// setTimeout(()=>{location.href = './index.php?c=account&a=edit_qr&sid=' + $('#codeId').val();},500);
							} else {
								$.hideLoading();
								$.toast('删除失败', "forbidden");
							}
						},'json')
					}else{
						$.hideLoading();
						$.toast("至少选中一个！", "forbidden");
					}
					
				})
			})
			
		function inMinus(id) {
			var Num = $('#Num' + id).val();
			if (Num != 0) {
				Num = Num - 1;
				$('#Num' + id).val(Num)
			}
		}

		function inAdd(id) {
			var Num = $('#Num' + id).val();
			// if (Num < {
			// 		$imgListCount
			// 	}) {
				Num = parseInt(Num) + 1;
				$('#Num' + id).val(Num)
			// }
		}

		function delImg(id) {
			$.confirm("您确定要删除吗？", "确认删除", function() {
				$.showLoading('删除中...');
				
				$.post("<?php  echo url('account/edit_qr',array('op'=>'del'));?>", {
					'sid': $('#codeId').val(),
					'imgId': [id]
				}, function(data) {
					info = eval(data);
					if (info.s == 'ok') {
						$.hideLoading();
						$.toast("删除成功");
						$('#imgList' + id).animate({
							'left': -1000
						}, 800);
						$('#imgList' + id).slideUp(200);
						setTimeout(()=>{$('#imgList' + id).remove()},1e3)
					} else {
						$.hideLoading();
						$.toast('删除失败', "forbidden");
					}
				}, 'json')

			}, function() {
				//取消操作
			});

		}


		function updataImg(id) {
			$.showLoading('修改中...');
			$.post("<?php  echo url('account/edit_qr',array('op'=>'updata'));?>", {
				'sid': $('#codeId').val(),
				'weight': $('#Num' + id).val(),
				'imgId': id
			}, function(data) {
				info = eval(data);
				if (info.s == 'ok') {
					$.hideLoading();
					$.toast("修改成功");
					// location.href = './index.php?c=account&a=edit_qr&sid=' + $('#codeId').val();
				} else {
					$.hideLoading();
					$.toast('修改失败', "forbidden");
				}
			}, 'json')

		}

		$(function() {
			var $gallery = $("#gallery"),
				$galleryImg = $("#galleryImg"),
				$uploaderInput = $("#uploaderInput"),
				$uploaderFiles = $("#uploaderFiles");

			$uploaderFiles.on("click", "li", function() {
				$galleryImg.attr("src", this.getAttribute("img-data"));
				$gallery.fadeIn(100);
			});
			$gallery.on("click", function() {
				$gallery.fadeOut(100);
			});
		});


		function _CheckEx() {
			if ($('#Name').val() == "") {
				$.prompt("请输入活码名称", "码名未输入", function(text) {
					$('#Name').val(text);
				}, function() {
					$.toast("请输入活码名称", "forbidden");
				});
				return false;
			}
			if ($('#FaZhi').val() == "") {
				$.prompt("请输入阀值", "阀值未输入", function(text) {
					$('#FaZhi').val(text);
				}, function() {
					$.toast("请输入阀值", "forbidden");
				});
				return false;
			}
			if ($('#FaZhi').val() > 200) {
				$.prompt("阀值最大不得超过200,请重新输入", "阀值溢出", function(text) {
					$('#FaZhi').val(text);
				}, function() {
					$.toast("阀值溢出", "forbidden");
					$('#FaZhi').val("");
				});
				return false;
			}
			return true;
		}

		$(".bg-blue-b").click(function() {

			if (_CheckEx()) {
				var imgs = $('#uploaderFiles li');
				var qrCode = $('#qrcode img');
				var imgData = new Array();
				var nameData = new Array();
				for (var i = 0; i < imgs.length; i++) {
					imgData[i] = imgs[i].getAttribute('img-data');
					nameData[i] = imgs[i].getAttribute('name-data');
				}
				$.showLoading("保存中...");
				if (qrCode[0].getAttribute('src') == '') {
					$.hideLoading(); //加载中
					$.toast('活码获取失败', "forbidden");
					return false;
				}



				if (imgData == '') {
					imgData = '0';
				}
				if (nameData == '') {
					nameData = '0';
				}

				$.post("<?php  echo url('account/upfile',array('op'=>'edit'));?>", {
					'codeId': $('#codeId').val(),
					'Name': $('#Name').val(),
					'FaZhi': $('#FaZhi').val(),
					'qrCode': qrCode[0].getAttribute('src'),
					'imgdata': imgData,
					'namedata': nameData
				}, function(data) {
					info = eval(data);
					// console.log(data)
					if (info.s == "ok") {
						$.hideLoading(); //加载中

						$.confirm("接下来你可以编辑了", "保存成功", function() {
							location.href = './index.php?c=account&a=edit_qr&sid=' + $('#codeId').val();
						}, function() {
							location.href = './index.php?c=account&a=myqr&';
						})
					} else {
						$.hideLoading(); //加载中
						$.toast(info.msg, "forbidden");
					}


				}, 'json')
			}
		})


		function previewImage(file) {

			var MAXWIDTH = 100;
			var MAXHEIGHT = 200;

			var tmpl =
				'<li class="weui_uploader_file" style="background-image:url(#url#)" img-data="#url#" name-data="#img_name#"></li>';

			if (file.files.length > 0) {
				var tempFileName;
				var flagLength = 0;
				var reader = new FileReader();
				if (file.files && file.files[flagLength]) {
					reader.readAsDataURL(file.files[flagLength]);
					reader.onload = function(evt) {
						tempFileName = file.files[flagLength].name.slice(0, file.files[flagLength].name.lastIndexOf("."));
						if (evt.target.result) {
							$('#uploaderFiles').append($(tmpl.replace(/#url#/g, evt.target.result).replace(/#img_name#/, tempFileName)));
						}
						flagLength++;
						if (flagLength < file.files.length) {
							reader.readAsDataURL(file.files[flagLength]); //读取文件 再次调用onload
						}
					}
				}
			}
		}
	</script>
	</body>

	</html>
