<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-wynters', TEMPLATE_INCLUDEPATH)) : (include template('common/header-wynters', TEMPLATE_INCLUDEPATH));?>
<body class="fixed-sidebar full-height-layout gray-bg" style="overflow:hidden">
    <div id="wrapper">
        <!--左侧导航开始-->
        <nav class="navbar-default navbar-static-side" role="navigation">
            <div class="nav-close"><i class="fa fa-times-circle"></i>
            </div>
            <div class="sidebar-collapse">
                <ul class="nav" id="side-menu">
                    <li class="nav-header">
                        <div class="dropdown profile-element">
                            <span><img alt="image" class="img-circle" src="<?php  echo $_W['siteroot'];?>web/resource/wynters/img/profile_small.jpg" /></span>
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <span class="clear">
                               <span class="block m-t-xs"><strong class="font-bold">Admin</strong></span>
                                <span class="text-muted text-xs block">超级管理员<b class="caret"></b></span>
                                </span>
                            </a>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="<?php  echo url('user/logout');?>">安全退出</a>
                                </li>
                            </ul>
                        </div>
                        <div class="logo-element">H+
                        </div>
                    </li>
					
					<li>
                        <a class="J_menuItem" href="<?php  echo url('account/index');?>"><i class="fa fa-user"></i> <span class="nav-label">首页</span></a>
                    </li>

                    <li>
                        <a class="J_menuItem" href="<?php  echo url('member/list');?>"><i class="fa fa-user"></i> <span class="nav-label">会员列表</span></a>
                    </li>
      
                    <!--li>
                        <a href="#"><i class="fa fa-edit"></i> <span class="nav-label">活码管理</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a class="J_menuItem" href="<?php  echo url('qr/list');?>">活码列表</a>
                            </li>
                            <li><a class="J_menuItem" href="<?php  echo url('qr/img');?>">图片列表</a>
                            </li>
                        </ul>
                    </li-->
                  <li>
                        <a href="#"><i class="fa fa-cutlery"></i> <span class="nav-label">系统设置</span><span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li><a class="J_menuItem" href="<?php  echo url('member/site');?>">前台设置</a>
                            </li>
                            <li>
                               <a href="#">管理设置 <span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li><a class="J_menuItem" href="<?php  echo url('user/profile');?>">修改密码</a>
                                    </li>
                                    <li><a class="J_menuItem" href="<?php  echo url('user/display');?>">管理列表</a>
                                    </li>
                                    <!--li><a class="J_menuItem" href="<?php  echo url('user/group');?>">管理组</a>
                                    </li-->
                                </ul>
                             </li>
                            </li>
                                <li>
                               <a href="#">系统设置 <span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <!--li><a class="J_menuItem" href="<?php  echo url('system/updatecache');?>">更新缓存</a>
                                    </li-->
                                    <li><a class="J_menuItem" href="<?php  echo url('system/site');?>">站点设置</a>
                                    </li>
                                    <!--li><a class="J_menuItem" href="<?php  echo url('system/attachment');?>">附件设置</a>
                                    </li>
                                     <li><a class="J_menuItem" href="<?php  echo url('system/sysinfo');?>">系统信息</a>
                                    </li-->
                                     <li><a class="J_menuItem" href="<?php  echo url('system/logs');?>">查看日志</a>
                                    </li>
                                </ul>
                             </li>
                            <li>
                               <a href="#">系统工具 <span class="fa arrow"></span></a>
                                <ul class="nav nav-third-level">
                                    <li><a class="J_menuItem" href="<?php  echo url('system/database');?>">数据库</a>
                                    </li>
                                    <!--li><a class="J_menuItem" href="<?php  echo url('system/tools/scan');?>">木马查杀</a>
                                    </li>
                                    <li><a class="J_menuItem" href="<?php  echo url('system/tools/bom');?>">BOM检测</a>
                                    </li>
                                     <li><a class="J_menuItem" href="<?php  echo url('system/optimize');?>">性能优化</a>
                                    </li>
                                     <li><a class="J_menuItem" href="<?php  echo url('system/filecheck');?>">文件验效</a>
                                    </li-->
                                </ul>
                             </li>
                           </li>
                        </ul>
                   </li>
                </ul>
            </div>
        </nav>
        <!--左侧导航结束-->
        <!--右侧部分开始-->
        <div id="page-wrapper" class="gray-bg dashbard-1">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    
                    <ul class="nav navbar-top-links navbar-right">
                        <li class="hidden-xs">
                            <a class="J_menuItem" data-index="0"><i class="fa fa-home"></i>前台首页</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <div class="row content-tabs">
                <button class="roll-nav roll-left J_tabLeft"><i class="fa fa-backward"></i>
                </button>
                <nav class="page-tabs J_menuTabs">
                    <div class="page-tabs-content">
                        <a href="javascript:;" class="active J_menuTab" data-id="<?php  echo url('account/index');?>">首页</a>
                    </div>
                </nav>
                <button class="roll-nav roll-right J_tabRight"><i class="fa fa-forward"></i>
                </button>
                <div class="btn-group roll-nav roll-right">
                    <button class="dropdown J_tabClose" data-toggle="dropdown">关闭操作<span class="caret"></span>

                    </button>
                    <ul role="menu" class="dropdown-menu dropdown-menu-right">
                        <li class="J_tabCloseAll"><a>关闭全部选项卡</a>
                        </li>
                        <li class="J_tabCloseOther"><a>关闭其他选项卡</a>
                        </li>
                    </ul>
                </div>
                <a href="<?php  echo url('user/logout');?>" class="roll-nav roll-right J_tabExit"><i class="fa fa fa-sign-out"></i> 退出</a>
            </div>
            <div class="row J_mainContent" id="content-main">
                <iframe class="J_iframe" name="iframe0" width="100%" height="100%" src="<?php  echo url('account/index');?>" frameborder="0" data-id="<?php  echo url('account/index');?>" seamless></iframe>
            </div>
            <div class="footer">
                <div class="pull-right">&copy; 2017 <a href="http://www.iheynet.com/" target="_blank">iheynet</a>
                </div>
            </div>
        </div>
        <!--右侧部分结束-->
        </div>
    </div>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer-js', TEMPLATE_INCLUDEPATH)) : (include template('common/footer-js', TEMPLATE_INCLUDEPATH));?>
    </body>
    </html>