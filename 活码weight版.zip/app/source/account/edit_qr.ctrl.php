<?php
defined('IN_IA') or exit('Access Denied');
define('IN_GW', true);

$member = $_W['user'];

$Qr = mc_getQr($_GPC[sid]);
if(empty($Qr)){
	message('二维码已经删除，或者不存在',url('account/myqr'),'error');
}

$imgList = mc_getImg($_GPC[sid]);
$imgListCount = count($imgList);
$op = $_GPC['op'];
$imgId = $_GPC['imgId'];
$delEg = $_GPC['delEg'];

if ($op == 'del'){
	if(!empty($imgId)){
		if(count($imgId) == 1){
			 $imgIdStr = $imgId[0];
			 if(mc_delImg(intval($imgIdStr))){
				$response = array('s' => 'ok', 'msg' =>1);
			 }else{
				$response = array('s' => 'no', 'msg' =>0);
			 };
		}else{
			for ($i=0; $i < count($imgId); $i++) { 
			  $imgIdStr = $imgId[$i];
			  mc_delImg(intval($imgIdStr));
			}
			$response = array('s' => 'ok', 'msg' =>1);
		}
		
	}else{
		$response = array('s' => 'no', 'msg' =>0);
	}
  
 // 	if(mc_delImg(intval($_GPC['imgId']))){
	// 	
	// }else{
	// 	$response = array('s' => 'no', 'msg' =>0);
	// }

    exit(json_encode($response));

}elseif($op == 'updata'){
	
	
	if($_GPC['weight']==0){
		$w_count = 0;
	}else{
		$Qr = mc_getQr($_GPC[sid]);
		$qrFaZhi = $Qr['fazhi'];
		$OneCount = mc_getOneCount(intval($_GPC['imgId']));
		$w_count = intval($qrFaZhi)+intval($OneCount);
	}
	
 	if(mc_updateImg(array('weight'=>$_GPC['weight'],'w_count'=>$w_count),intval($_GPC['imgId']))){
		$response = array('s' => 'ok', 'msg' =>1);
	}else{
		$response = array('s' => 'no', 'msg' =>0);
	}

    exit(json_encode($response));
}elseif($op == 'deleg'){

	if(mc_delEg($_GPC[sid],intval($delEg))){
		$response = array('s' => 'ok', 'msg' =>1);
	}else{
		$response = array('s' => 'no', 'msg' =>0);
	}
	exit(json_encode($response));
}
//print_r($Qr);

/*
$fans = pdo_fetchcolumn('SELECT COUNT(*) FROM '.tablename('mc_members')."WHERE parent = $uid or parent2 = $uid or parent3 = $uid or parent4 = $uid or parent5 = $uid or parent6 = $uid or parent7 = $uid or parent8 = $uid or parent9 = $uid or parent10 = $uid or parent11 = $uid or parent12 = $uid");
$news = pdo_fetchall('SELECT * FROM '.tablename('mc_article').'order by id desc limit 10');
*/
template('account/edit_qr');