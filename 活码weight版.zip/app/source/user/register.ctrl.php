<?php
/**
 * 注册会员
 */
defined('IN_IA') or exit('Access Denied');
define('IN_GW', true);

if (checksubmit('register')) {
	load()->model('user');
	$data = $_GPC['data'];
	$name = $data['username'];

	if (pdo_fetch('SELECT * FROM '.tablename('mc_members')." WHERE `username` = '$name'")) {
		message('抱歉，该用户名已存在！','refresh','error');
	}
	if(empty($data['username']))
		message('抱歉，请输入用户名！','refresh','error');
	if(empty($data['password']))
		message('抱歉，请输入用户密码！','refresh','error');
	if(empty($_GPC['password']))
		message('抱歉，请输入确认密码！','refresh','error');
	if($data['password'] != $_GPC['password'])
		message('抱歉，两次输入密码不同，请重新输入！','refresh','error');




	$salt = mt_rand(11111,99999);
	$data['password'] = member_hash($data['password'],$salt);
	$data['salt'] = $salt;
	$data['joindate'] = time();
	$data['joinip'] = $_SERVER["REMOTE_ADDR"];

	if(!empty(pdo_insert(mc_members, $data))){
		message('恭喜，注册会员成功！',url('user/login'),'success');
	}else{
		message('抱歉，注册失败，请重试！','refresh','error');
	}
}
template('user/register');