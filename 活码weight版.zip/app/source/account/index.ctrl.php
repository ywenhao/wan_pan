<?php
/**
 * 个人主页
 */
defined('IN_IA') or exit('Access Denied');
define('IN_GW', true);

$member = $_W['user'];

/*
$fans = pdo_fetchcolumn('SELECT COUNT(*) FROM '.tablename('mc_members')."WHERE parent = $uid or parent2 = $uid or parent3 = $uid or parent4 = $uid or parent5 = $uid or parent6 = $uid or parent7 = $uid or parent8 = $uid or parent9 = $uid or parent10 = $uid or parent11 = $uid or parent12 = $uid");
$news = pdo_fetchall('SELECT * FROM '.tablename('mc_article').'order by id desc limit 10');
*/
template('account/index');
