<?php
/**
 * 二维码识别
 */

_checkIsMobileChat();



$sid = $_GPC['sid'];


$Qr = mc_getQr($sid);


$cookiceVlues = $_GPC['__'.$Qr[id]];

if(empty($cookiceVlues)){

$qrCount = $Qr['count'];


$qrFaZhi = $Qr['fazhi'];

if(mc_getCountWeight($sid)){
		
	if(mc_getScanImgAll($sid)){  		
		$ScanData = mc_getScanImgWeight($sid);
		if($ScanData['count']>=$ScanData['w_count']-1){
			mc_updateImg(array('weight'=> -1,'w_count'=> 0 ),$ScanData['id']);
		}
	}  
	
}else{
	
	if(mc_getScanImgAll($sid)){ 
		
		$ScanData = mc_getScanImg($sid,$qrFaZhi);
		
		$i = 1;
		while (mc_getScanImg($sid,$qrFaZhi*$i)==false) {
			$i++;
		$ScanData = mc_getScanImg($sid,$qrFaZhi*$i);
		}
	}  
}
qrScanPlus($sid,$ScanData['id']);
$img = $ScanData['img'];
//===========
mc_addScan(array('value' => $ScanData['id'],'add_time'=>time(),'sid'=>$sid,'img'=>$img));
//===========
isetcookie('__'.$Qr[id],$ScanData['id'], 999 * 86400);

}else{
	$img = get_ScanImg($sid,$cookiceVlues);
}

template('account/qr');