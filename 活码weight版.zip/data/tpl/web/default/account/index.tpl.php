<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-wynters', TEMPLATE_INCLUDEPATH)) : (include template('common/header-wynters', TEMPLATE_INCLUDEPATH));?>
<body class="gray-bg">

</body>

</html>