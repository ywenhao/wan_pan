<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-wynters', TEMPLATE_INCLUDEPATH)) : (include template('common/header-wynters', TEMPLATE_INCLUDEPATH));?>
<body class="gray-bg">
    <div class="wrapper wrapper-content  animated fadeInRight">
        <div class="row">
            <div class="col-sm-8">
                <div class="ibox">
                    <div class="ibox-content">
                        <span class="text-muted small pull-right">最后更新：<i class="fa fa-clock-o"></i> <?php  echo date('Y-m-d H:i:s',time())?></span>
                        <h2>会员列表</h2>
                        <p>
                            欢迎使用
                        </p>
                        <!--div class="input-group">
                            <input type="text" placeholder="查找客户" class="input form-control">
                            <span class="input-group-btn">
                                        <button type="button" class="btn btn btn-primary"> <i class="fa fa-search"></i> 搜索</button>
                                </span>
                        </div-->
                        <div class="clients-list">
                            <ul class="nav nav-tabs">
                                <span class="pull-right small text-muted"><?php  echo $total;?>个会员</span>
                                <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-user"></i>MemberList</a>
                                </li>
                                <!--li class=""><a data-toggle="tab" href="#tab-2"><i class="fa fa-briefcase"></i> 公司</a>
                                </li-->
                            </ul>
                            <div class="tab-content">
                                <div id="tab-1" class="tab-pane active">
                                    <div class="full-height-scroll">
                                        <div class="table-responsive">
                                            <table class="table table-striped table-hover">
                                                <tbody>
                                                <?php  if(is_array($memberList)) { foreach($memberList as $memberList) { ?>
                                                    <tr onclick="getMemberInfo(<?php  echo $memberList['uid'];?>)">
                                                   		 <td class="contact-type"><i class="fa fa-user"> </i>
                                                        </td>
                                                        <td class="client-avatar"><?php  echo $memberList['uid'];?></td>
                                                        <td><a data-toggle="tab" href="#contact-1" class="client-link"><?php  echo $memberList['username'];?></a>
                                                        </td>
                                                        <td> <?php  if($memberList['vip']< 0) { ?>
                                                        <span class="label label-danger">VIP</span>
                                                        <?php  } else { ?>
                                                        <span class="label label-info">普通用户</span>
                                                        <?php  } ?>
                                                        </td>
                                                        <td class="contact-type"><i class="fa fa-clock-o"> </i>
                                                        </td>
                                                        <td><?php  echo date('Y-m-d H:i:s',$memberList['lastvisit'])?></td>
                                                        <td class="client-status" id="rSta<?php  echo $memberList['uid'];?>">
                                                        <?php  if(!empty($memberList['status'])) { ?>				
                                                        <span class="label label-warning">等待审核</span>
                                                        <?php  } else { ?>
                                                        <span class="label label-primary">已审核</span>
                                                        <?php  } ?>
                                                        </td>
                                                    </tr>
                                                     <?php  } } ?>
                                                </tbody>
                                            </table>

                                        </div>
                                        	 <?php  echo $pager;?>		
                                    </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-4" id="memberInfo" style="display: none;">
                <div class="ibox">

                    <div class="ibox-content">
                        <div class="tab-content">
                            <div id="contact-1" class="tab-pane active">
                                <div class="row m-b-lg">
                                    <div class="col-lg-4 text-center">
                                        <h2 id="userName">张有为</h2>

                                        <!--div class="m-b-sm">
                                            <img alt="image" class="img-circle" src="img/a2.jpg" style="width: 62px">
                                        </div>
                                    </div>
                                    <div class="col-lg-8">
                                        <h3>
                                                个人简介
                                            </h3>

                                        <p>
                                            李彦宏，百度公司创始人、董事长兼首席执行官，全面负责百度公司的战略规划和运营管理。
                                        </p>
                                        <p>

                                            1991年，李彦宏毕业于北京大学信息管理专业，随后前往美国布法罗纽约州立大学完成计算机科学硕士学位，先后担任道·琼斯公司高级顾问、《华尔街日报》网络版实时金融信息系统设计者，以及国际知名互联网企业——Infoseek公司资深工程师。李彦宏所持有的“超链分析”技术专利，是奠定整个现代搜索引擎发展趋势和方向的基础发明之一。
                                        </p>
                                        <br>
                                        <button type="button" class="btn btn-primary btn-sm btn-block"><i class="fa fa-envelope"></i> 发送消息
                                        </button>
                                    </div-->
                                </div>
                                <div class="client-detail">
                                    <div class="full-height-scroll">

                                        <strong>当前信息</strong>
                                        <ul class="list-group clear-list">
                                            <li class="list-group-item fist-item" id="isVip" style="text-align: center;">
                                            
                                            </li>
                                            <li class="list-group-item" id="status" style="text-align: center;">
                                                
                                            </li>
                                            <li class="list-group-item" id = "regTime" style="text-align: center;">
                                               
                                            </li>
                                        </ul>
                                        <!--strong>备注</strong>
                                        <p>
                                            40亿影帝黄渤先生明明可以靠脸吃饭，可是他却偏偏靠才华，唱歌居然也这么好听！
                                        </p-->
                                        <hr/>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer-js', TEMPLATE_INCLUDEPATH)) : (include template('common/footer-js', TEMPLATE_INCLUDEPATH));?>
    <script type="text/javascript">
        $(function(){$(".full-height-scroll").slimScroll({height:"100%"})});
        function getMemberInfo(uid){
        	$.post("<?php  echo url('member/list',array('op'=>'getMemberInfo'));?>", {'uid':uid}, function(data){
        info = eval(data);
        if(info.s=="ok"){
        	if ($('#memberInfo').css('display') == 'none') {
					$('#memberInfo').slideDown(1000);
        		}else{
        			$('#memberInfo').hide();
        			$('#memberInfo').slideDown(1000);
        		}
     		$('#userName').text(info.str.username);
     		if(info.str.vip == 1){
			$('#isVip').html('<span class="label label-danger">VIP</span>')
     		}else{
     		$('#isVip').html('<span class="label label-info">普通用户</span>')
     		}
     		if(info.str.status == 1){
			$('#status').html('<a href="javascript:;" onclick="adoptUser('+uid+')" class="label label-warning">通过审核</a>')
     		}else{
     		$('#status').html('<span class="label label-primary">已审核</span>')
     		}
     		$('#regTime').html('<i class="fa fa-clock-o"> </i>'+info.str.lastvisit);
        }else{
           $.hideLoading();//加载中
          $.toast(info.msg, "forbidden");
        }


  },'json')

 }
 function adoptUser(uid){
 	$.post("<?php  echo url('member/list',array('op'=>'adoptUser'));?>", {'uid':uid}, function(data){
        info = eval(data);
        if(info.s=="ok"){
			$('#status').html('<span class="label label-primary">已审核</span>')
			$('#rSta'+uid).html('<span class="label label-primary">已审核</span>')
     		}

  },'json')
 }

    </script>
    <script type="text/javascript" src="http://tajs.qq.com/stats?sId=9051096" charset="UTF-8"></script>
</body>

</html>