<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-gw', TEMPLATE_INCLUDEPATH)) : (include template('common/header-gw', TEMPLATE_INCLUDEPATH));?>
<div class="main">
	<div class="panel panel-info">
		<div class="panel-heading">用户信息</div>
		<div class="panel-body table-responsive">
		<table class="table table-hover">
			<tr>
				<th style="width:250px;">用户ID</th>
				<td><?php  echo $info['uid'];?></td>
			</tr>
			<tr>
				<th>当前公众号</th>
				<td><?php  echo $info['account'];?></td>
			</tr>
		</table>
		</div>
	</div>
	
	<div class="panel panel-info">
		<div class="panel-heading">系统信息</div>
		<div class="panel-body table-responsive">
		<table class="table table-hover">
			<tr>
				<th style="width:250px;">微擎程序版本</th>
				<td>WeEngine <?php  echo IMS_VERSION;?> Release  <?php  echo IMS_RELEASE_DATE;?> &nbsp; &nbsp; <a href="http://www.we7.cc" target="_blank">查看最新版本</a></td>
			</tr>
			<tr>
				<th>产品系列</th>
				<td>【Wynters】版
				</td>
			</tr>
			<tr>
				<th>服务器系统</th>
				<td><?php  echo $info['os'];?></td>
			</tr>
			<tr>
				<th>PHP版本 </th>
				<td>PHP Version <?php  echo $info['php'];?></td>
			</tr>
			<tr>
				<th>服务器软件</th>
				<td><?php  echo $info['sapi'];?></td>
			</tr>
			<tr>
				<th>服务器 MySQL 版本</th>
				<td><?php  echo $info['mysql']['version'];?></td>
			</tr>
			<tr>
				<th>上传许可</th>
				<td><?php  echo $info['limit'];?></td>
			</tr>
			<tr>
				<th>当前数据库尺寸</th>
				<td><?php  echo $info['mysql']['size'];?></td>
			</tr>
			<tr>
				<th>当前附件根目录</th>
				<td><?php  echo $info['attach']['url'];?></td>
			</tr>
			<tr>
				<th>当前附件尺寸</th>
				<td><?php  echo $info['attach']['size'];?></td>
			</tr>
		</table>
		</div>
	</div>

	<?php  if($_W['isfounder']) { ?>
		<div class="panel panel-info">
			<div class="panel-heading">微擎开发团队</div>
			<div class="panel-body table-responsive">
			<table class="table table-hover">
				<tr>
					<th style="width:250px;">版权所有</th>
					<td><a href="http://www.we7.cc/" target="_blank"><b>We7 Team</b></a></td>
				</tr>
				<tr>
					<th>Team 成员</th>
					<td>
						<a href="http://bbs.we7.cc/?10906" class="lightlink2 smallfont" target="_blank">袁文涛</a>; &nbsp;
						<a href="http://bbs.we7.cc/?83" class="lightlink2 smallfont" target="_blank">任超 (米粥)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?19511" class="lightlink2 smallfont" target="_blank">宋建君 (Gorden)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?38439" class="lightlink2 smallfont" target="_blank">杨慧锋 (灯火阑珊)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?64869" class="lightlink2 smallfont" target="_blank">姚晶晶 </a>; &nbsp;
						<a href="http://bbs.we7.cc/?83750" class="lightlink2 smallfont" target="_blank">赵波 </a>; &nbsp;
						<a href="http://bbs.we7.cc/?90981" class="lightlink2 smallfont" target="_blank">曹春江 </a>; &nbsp;
						<a href="http://bbs.we7.cc/?111463" class="lightlink2 smallfont" target="_blank">杨峰 </a>; &nbsp;
						<a href="http://bbs.we7.cc/?56310" class="lightlink2 smallfont" target="_blank">侯琪琪 (琪琪)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?52995" class="lightlink2 smallfont" target="_blank">杨欣雨 (小雨)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?11877" class="lightlink2 smallfont" target="_blank">赵小雷 (擎擎)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?75780" class="lightlink2 smallfont" target="_blank">蔡帅帅 (小帅)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?80040" class="lightlink2 smallfont" target="_blank">朱传宝 (阿宝)</a>; &nbsp;
						<a href="http://bbs.we7.cc/?98655" class="lightlink2 smallfont" target="_blank">蒋康康 (阿康)</a>; &nbsp;
					</td>
				</tr>
					<tr>
					<th>官方交流群</th>
					<td><a target="_blank" href="http://wp.qq.com/wpa/qunwpa?idkey=874aa2f28317557b6f0874692c927974611b0c193c9b36ab17b64f9cbd43e5ad">32385562</a></td>
				</tr>
				<tr>
					<th>相关链接</th>
					<td>
						<a href="http://www.we7.cc/" class="lightlink2" target="_blank">公司网站</a>,
						<a href="http://www.we7.cc/purchase.html" class="lightlink2" target="_blank">购买授权</a>,
						<a href="http://bbs.we7.cc/forum.php?mod=forumdisplay&fid=36" class="lightlink2" target="_blank">更多模块</a>,
						<a href="http://www.we7.cc/manual/" class="lightlink2" target="_blank">文档</a>,
						<a href="http://bbs.we7.cc/" class="lightlink2" target="_blank">讨论区</a>
					</td>
				</tr>
			</table>
			</div>
		</div>
	<?php  } ?>
</div>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer-gw', TEMPLATE_INCLUDEPATH)) : (include template('common/footer-gw', TEMPLATE_INCLUDEPATH));?>
