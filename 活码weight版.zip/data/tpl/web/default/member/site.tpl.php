<?php defined('IN_IA') or exit('Access Denied');?><?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-wynters', TEMPLATE_INCLUDEPATH)) : (include template('common/header-wynters', TEMPLATE_INCLUDEPATH));?>
<body class="gray-bg">
    <div class="wrapper wrapper-content  animated fadeInRight">
        <div class="row">
            <div class="col-sm-8">
                <div class="ibox">
                    <div class="ibox-content">
                        <div class="clients-list" style="width: 100%;">
                            <ul class="nav nav-tabs">
                                <li class="active"><a data-toggle="tab" href="#tab-1"><i class="fa fa-user"></i>前台首页设置</a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div id="tab-1" class="tab-pane active">
                                    <div class="full-height-scroll">
                                        <div class="table-responsive">
                 

<div class="main">
    <form action="" method="post" class="form-horizontal form" id="setting-form">
        <div class="panel panel-default">
            <div class="panel-heading">基本参数设置</div>
            <div class="panel-body">
                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">平台名称</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[name]" class="form-control" value="<?php  echo $yunma['name'];?>" />
                    </div>
                </div>

                 <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">logo</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[logo]', $yunma['logo']);?>
                    </div>
                </div>
				<!--div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">活码域名</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[ffym]" class="form-control" value="<?php  echo $yunma['ffym'];?>" />
                    </div>
                </div-->
                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">首页轮播图</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[logo1]', $yunma['logo1']);?>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">首页轮播图2</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[logo2]', $yunma['logo2']);?>
                    </div>
                </div>

                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">首页轮播图3</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[logo3]', $yunma['logo3']);?>
                    </div>
                </div>
</div>
</div>

<div class="panel panel-default">
            <div class="panel-heading">平台设置</div>

                  <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">页首说明</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[ex]" class="form-control" value="<?php  echo $yunma['ex'];?>" />
                    </div>
                </div>
                


                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题1图</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[title1_img]', $yunma['title1_img']);?>
                    </div>
                </div> 

             <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题1标题</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title1_title]" class="form-control" value="<?php  echo $yunma['title1_title'];?>" />
                    </div>
                </div>

            <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题1说明</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title1_ex]" class="form-control" value="<?php  echo $yunma['title1_ex'];?>" />
                    </div>
                </div>

<p></p><p></p>
                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题2图</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[title2_img]', $yunma['title2_img']);?>
                    </div>
                </div> 

             <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题2标题</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title2_title]" class="form-control" value="<?php  echo $yunma['title2_title'];?>" />
                    </div>
                </div>

            <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题2说明</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title2_ex]" class="form-control" value="<?php  echo $yunma['title2_ex'];?>" />
                    </div>
                </div>

<p></p><p></p>
                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题3图</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[title3_img]', $yunma['title3_img']);?>
                    </div>
                </div> 

             <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题3标题</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title3_title]" class="form-control" value="<?php  echo $yunma['title3_title'];?>" />
                    </div>
                </div>

            <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题3说明</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title3_ex]" class="form-control" value="<?php  echo $yunma['title3_ex'];?>" />
                    </div>
                </div>


<p></p><p></p>

            <!--div class="panel-body">
                <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题4图</label>
                    <div class="col-sm-8">
                        <?php  echo tpl_form_field_image('data[title4_img]', $yunma['title4_img']);?>
                    </div>
                </div> 

             <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题4标题</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title4_title]" class="form-control" value="<?php  echo $yunma['title4_title'];?>" />
                    </div>
                </div>

            <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">标题4说明</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[title4_ex]" class="form-control" value="<?php  echo $yunma['title4_ex'];?>" />
                    </div>
                </div>



            <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">用户中心说明1</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[member_content1]" class="form-control" value="<?php  echo $yunma['member_content1'];?>" />
                    </div>
                </div>

  <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">用户中心说明2</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[member_content2]" class="form-control" value="<?php  echo $yunma['member_content2'];?>" />
                    </div>
                </div>

  <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">用户中心说明3</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[member_content3]" class="form-control" value="<?php  echo $yunma['member_content3'];?>" />
                    </div>
                </div>
  <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">用户中心说明4</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[member_content4]" class="form-control" value="<?php  echo $yunma['member_content4'];?>" />
                    </div>
                </div>

                  <div class="form-group">
                    <label class="col-xs-12 col-sm-3 col-md-2 col-lg-2 control-label">用户中心说明5</label>
                    <div class="col-sm-8">
                        <input type="text" name="data[member_content5]" class="form-control" value="<?php  echo $yunma['member_content5'];?>" />
                    </div>
                </div>












                <div class="form-group">
                    <div class="col-xs-12 col-sm-9 col-md-10 col-lg-10 col-sm-offset-3 col-md-offset-2 col-lg-offset-2">
                        <input name="submit" type="submit" value="提交" class="btn btn-primary" />
                        <input type="hidden" name="token" value="<?php  echo $_W['token'];?>" />
                    </div>
              </div>
        </div-->
        </div>
    </form>
</div>




                                        </div>
                                    </div>
                                </div>
                                <div id="tab-2" class="tab-pane">
                                    <div class="full-height-scroll">
                                        <div class="table-responsive">

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer-js', TEMPLATE_INCLUDEPATH)) : (include template('common/footer-js', TEMPLATE_INCLUDEPATH));?>
    <script type="text/javascript">
    </script>
    <script type="text/javascript" src="http://tajs.qq.com/stats?sId=9051096" charset="UTF-8"></script>
</body>

</html>