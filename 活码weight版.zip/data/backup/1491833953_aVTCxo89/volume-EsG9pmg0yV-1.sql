DROP TABLE IF EXISTS ims_core_attachment;
CREATE TABLE `ims_core_attachment` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `filename` varchar(255) NOT NULL,
  `attachment` varchar(255) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

INSERT INTO ims_core_attachment VALUES 
('24','0','1','banner1.jpg','images/0/2017/04/sPW8TjWRop8gpJcJ2SP2OOjWptO06O.jpg','1','1491832579'),
('25','0','1','banner1.jpg','images/0/2017/04/N4SYbWLaTLl66L4JC4456fXl5454cB.jpg','1','1491832582'),
('26','0','1','banner1.jpg','images/0/2017/04/KffjkwmJjTJX3cg77NyfRNDHBMxxEn.jpg','1','1491832940'),
('27','0','1','banner1.jpg','images/0/2017/04/of9kqcp9sQ9C38okVQ7N9UT3G9t8yP.jpg','1','1491832942'),
('28','0','1','1.png','images/0/2017/04/Pzluu8Uc6C0cCcFNc8tcUs38O3c4yu.png','1','1491833369'),
('29','0','1','2.png','images/0/2017/04/ZBV9oNCV66Si69ZIz6i9Qqi96Nq9EE.png','1','1491833413'),
('30','0','1','3.png','images/0/2017/04/JB60lRW703b88TGsWSL7sky0bu0VYU.png','1','1491833591');


DROP TABLE IF EXISTS ims_core_cache;
CREATE TABLE `ims_core_cache` (
  `key` varchar(50) NOT NULL,
  `value` mediumtext NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO ims_core_cache VALUES 
('userbasefields','a:44:{s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:6:\"mobile\";s:12:\"手机号码\";s:5:\"email\";s:12:\"电子邮箱\";s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"gender\";s:6:\"性别\";s:5:\"birth\";s:6:\"生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:6:\"地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:6:\"reside\";s:9:\"居住地\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";}'),
('usersfields','a:44:{s:7:\"uniacid\";s:17:\"同一公众号id\";s:7:\"groupid\";s:8:\"分组id\";s:7:\"credit1\";s:6:\"积分\";s:7:\"credit2\";s:6:\"余额\";s:7:\"credit3\";s:19:\"预留积分类型3\";s:7:\"credit4\";s:19:\"预留积分类型4\";s:7:\"credit5\";s:19:\"预留积分类型5\";s:7:\"credit6\";s:19:\"预留积分类型6\";s:10:\"createtime\";s:12:\"加入时间\";s:6:\"mobile\";s:12:\"手机号码\";s:5:\"email\";s:12:\"电子邮箱\";s:8:\"realname\";s:12:\"真实姓名\";s:8:\"nickname\";s:6:\"昵称\";s:6:\"avatar\";s:6:\"头像\";s:2:\"qq\";s:5:\"QQ号\";s:6:\"gender\";s:6:\"性别\";s:5:\"birth\";s:6:\"生日\";s:13:\"constellation\";s:6:\"星座\";s:6:\"zodiac\";s:6:\"生肖\";s:9:\"telephone\";s:12:\"固定电话\";s:6:\"idcard\";s:12:\"证件号码\";s:9:\"studentid\";s:6:\"学号\";s:5:\"grade\";s:6:\"班级\";s:7:\"address\";s:6:\"地址\";s:7:\"zipcode\";s:6:\"邮编\";s:11:\"nationality\";s:6:\"国籍\";s:6:\"reside\";s:9:\"居住地\";s:14:\"graduateschool\";s:12:\"毕业学校\";s:7:\"company\";s:6:\"公司\";s:9:\"education\";s:6:\"学历\";s:10:\"occupation\";s:6:\"职业\";s:8:\"position\";s:6:\"职位\";s:7:\"revenue\";s:9:\"年收入\";s:15:\"affectivestatus\";s:12:\"情感状态\";s:10:\"lookingfor\";s:13:\" 交友目的\";s:9:\"bloodtype\";s:6:\"血型\";s:6:\"height\";s:6:\"身高\";s:6:\"weight\";s:6:\"体重\";s:6:\"alipay\";s:15:\"支付宝帐号\";s:3:\"msn\";s:3:\"MSN\";s:6:\"taobao\";s:12:\"阿里旺旺\";s:4:\"site\";s:6:\"主页\";s:3:\"bio\";s:12:\"自我介绍\";s:8:\"interest\";s:12:\"兴趣爱好\";}'),
('setting','a:4:{s:8:\"platform\";a:5:{s:5:\"token\";s:32:\"mh3S0ol7Kkv7lKdhDg3x9g0vy97SSvK1\";s:14:\"encodingaeskey\";s:43:\"Ja8a6mYVamP8O6r13f677oUMOpmp5Z7Yag1h5Uop56G\";s:9:\"appsecret\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:9:\"authstate\";i:1;}s:8:\"authmode\";i:1;s:9:\"copyright\";a:3:{s:6:\"status\";s:1:\"1\";s:10:\"verifycode\";s:1:\"0\";s:6:\"reason\";s:14:\"11111111111111\";}s:8:\"register\";a:4:{s:4:\"open\";i:0;s:6:\"verify\";i:0;s:4:\"code\";i:0;s:7:\"groupid\";i:0;}}'),
('yunma','a:23:{s:4:\"name\";s:6:\"云码\";s:4:\"logo\";s:0:\"\";s:5:\"logo1\";s:51:\"images/0/2017/04/of9kqcp9sQ9C38okVQ7N9UT3G9t8yP.jpg\";s:5:\"logo2\";s:51:\"images/0/2017/04/of9kqcp9sQ9C38okVQ7N9UT3G9t8yP.jpg\";s:5:\"logo3\";s:51:\"images/0/2017/04/of9kqcp9sQ9C38okVQ7N9UT3G9t8yP.jpg\";s:2:\"ex\";s:242:\"微信群二维码满100人以后，就不能扫描入了怎么办？用码云就能完美解决这个问题。使用微信群活码工具，二维码永不过期，不受100人限制。每天海量流量。轻轻松松一天加满20个群！\";s:10:\"title1_img\";s:51:\"images/0/2017/04/Pzluu8Uc6C0cCcFNc8tcUs38O3c4yu.png\";s:12:\"title1_title\";s:24:\"什么是微信活码？\";s:9:\"title1_ex\";s:120:\"一张统一的二维码扫描后可以自动切换多张群二维码。用户扫描100次后自动切换到下一张！\";s:10:\"title2_img\";s:51:\"images/0/2017/04/ZBV9oNCV66Si69ZIz6i9Qqi96Nq9EE.png\";s:12:\"title2_title\";s:15:\"群裂变利器\";s:9:\"title2_ex\";s:129:\"通过微信活码进行群裂变，二维码永不过期啦！还可以根据用户所在城市自动导入相应的二维码！\";s:10:\"title3_img\";s:51:\"images/0/2017/04/JB60lRW703b88TGsWSL7sky0bu0VYU.png\";s:12:\"title3_title\";s:12:\"数据统计\";s:9:\"title3_ex\";s:90:\"提供数据统计报告！提供精美的分析报告，让你的微信营销数据化！\";s:10:\"title4_img\";s:0:\"\";s:12:\"title4_title\";s:0:\"\";s:9:\"title4_ex\";s:0:\"\";s:15:\"member_content1\";s:0:\"\";s:15:\"member_content2\";s:0:\"\";s:15:\"member_content3\";s:0:\"\";s:15:\"member_content4\";s:0:\"\";s:15:\"member_content5\";s:0:\"\";}');


DROP TABLE IF EXISTS ims_core_performance;
CREATE TABLE `ims_core_performance` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `runtime` varchar(10) NOT NULL,
  `runurl` varchar(512) NOT NULL,
  `runsql` varchar(512) NOT NULL,
  `createtime` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_core_sendsms_log;
CREATE TABLE `ims_core_sendsms_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `content` varchar(255) NOT NULL,
  `result` varchar(255) NOT NULL,
  `createtime` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_core_settings;
CREATE TABLE `ims_core_settings` (
  `key` varchar(200) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO ims_core_settings VALUES 
('platform','a:5:{s:5:\"token\";s:32:\"mh3S0ol7Kkv7lKdhDg3x9g0vy97SSvK1\";s:14:\"encodingaeskey\";s:43:\"Ja8a6mYVamP8O6r13f677oUMOpmp5Z7Yag1h5Uop56G\";s:9:\"appsecret\";s:0:\"\";s:5:\"appid\";s:0:\"\";s:9:\"authstate\";i:1;}'),
('authmode','i:1;'),
('copyright','a:3:{s:6:\"status\";s:1:\"1\";s:10:\"verifycode\";s:1:\"0\";s:6:\"reason\";s:14:\"11111111111111\";}'),
('register','a:4:{s:4:\"open\";i:0;s:6:\"verify\";i:0;s:4:\"code\";i:0;s:7:\"groupid\";i:0;}');


DROP TABLE IF EXISTS ims_fanli_log;
CREATE TABLE `ims_fanli_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `loseid` int(10) unsigned NOT NULL COMMENT 'è¿”åˆ©æä¾›è€…',
  `getid` int(10) unsigned NOT NULL COMMENT 'èŽ·å¾—è¿”åˆ©è€…',
  `amount` double(10,2) unsigned DEFAULT NULL COMMENT 'è¿”åˆ©é‡‘é¢',
  `ordersn` varchar(30) NOT NULL,
  `add_time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_login_log;
CREATE TABLE `ims_login_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL COMMENT 'ip',
  `username` varchar(30) NOT NULL COMMENT 'ç”¨æˆ·å',
  `time` int(10) unsigned NOT NULL COMMENT 'ç™»å…¥æ—¶é—´',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=143 DEFAULT CHARSET=utf8;

INSERT INTO ims_login_log VALUES 
('1','112.12.76.131','123456','1491552100'),
('2','112.12.76.131','123456','1491552185'),
('3','112.12.76.131','123456','1491552188'),
('4','112.12.76.131','123456','1491552190'),
('5','112.12.76.131','123456','1491552191'),
('6','112.12.76.131','123456','1491552192'),
('7','112.12.76.131','123456','1491552193'),
('8','112.12.76.131','123456','1491552194'),
('9','112.12.76.131','123456','1491552195'),
('10','112.12.76.131','123456','1491552196'),
('11','112.12.76.131','123456','1491552197'),
('12','112.12.76.131','123456','1491552198'),
('13','112.12.76.131','123456','1491552199'),
('14','112.12.76.131','123456','1491552200'),
('15','112.12.76.131','123456','1491552201'),
('16','112.12.76.131','123456','1491552202'),
('17','112.12.76.131','123456','1491552203'),
('18','112.12.76.131','123456','1491552204'),
('19','112.12.76.131','123456','1491552205'),
('20','112.12.76.131','123456','1491552206'),
('21','112.12.76.131','123456','1491552207'),
('22','112.12.76.131','123456','1491552207'),
('23','112.12.76.131','123456','1491552209'),
('24','112.12.76.131','123456','1491552210'),
('25','112.12.76.131','123456','1491552210'),
('26','112.12.76.131','123456','1491552211'),
('27','112.12.76.131','123456','1491552212'),
('28','112.12.76.131','123456','1491552213'),
('29','112.12.76.131','123456','1491552214'),
('30','112.12.76.131','123456','1491552215'),
('31','112.12.76.131','123456','1491552216'),
('32','112.12.76.131','123456','1491552217'),
('33','112.12.76.131','123456','1491552218'),
('34','122.243.148.204','123456','1491555214'),
('35','122.243.148.204','123456','1491555281'),
('36','122.243.148.204','123456','1491555805'),
('37','183.55.69.152','test666','1491556965'),
('38','122.243.148.204','123456','1491559132'),
('39','122.243.148.204','123456','1491559153'),
('40','223.104.64.57','test666','1491559461'),
('41','122.243.148.204','123456','1491561658'),
('42','122.243.148.204','123456','1491562163'),
('43','183.58.75.131','test666','1491563436'),
('44','183.58.75.131','test666','1491563815'),
('45','183.58.75.131','test666','1491564258'),
('46','122.243.148.204','123456','1491564484'),
('47','122.243.148.204','123456','1491564511'),
('48','122.243.148.204','123456','1491564608'),
('49','122.243.148.204','123456','1491564654'),
('50','183.58.75.131','test666','1491564668'),
('51','183.58.75.131','test666','1491564674'),
('52','183.58.75.131','test666','1491564680'),
('53','183.58.75.131','test666','1491564720'),
('54','122.243.148.204','123456','1491564793'),
('55','122.243.148.204','123456','1491566050'),
('56','183.58.75.131','test666','1491566659'),
('57','183.58.75.131','test666','1491566734'),
('58','122.243.217.183','123456','1491567329'),
('59','122.243.148.204','123456','1491568169'),
('60','223.104.64.57','test666','1491568907'),
('61','122.243.217.183','123456','1491569410'),
('62','122.243.217.183','123456','1491569430'),
('63','122.243.217.183','123456','1491569500'),
('64','223.104.64.57','test666','1491569636'),
('65','122.243.217.183','123456','1491569729'),
('66','122.243.217.183','123456','1491572703'),
('67','122.243.148.204','123456','1491573952'),
('68','122.243.148.204','123456','1491574677'),
('69','122.243.148.204','123456','1491575728'),
('70','223.104.64.57','test666','1491576294'),
('71','223.104.64.57','test666','1491578163'),
('72','122.243.217.183','123456','1491579620'),
('73','122.243.148.204','123456','1491579988'),
('74','122.243.148.204','123456','1491579988'),
('75','122.243.217.183','123456','1491580005'),
('76','122.243.148.204','123456','1491580199'),
('77','183.58.75.131','test666','1491580550'),
('78','183.58.75.131','test666','1491580722'),
('79','122.243.217.183','123456','1491581067'),
('80','122.243.148.204','123456','1491581213'),
('81','122.243.217.183','123456','1491581493'),
('82','183.58.75.131','test666','1491581526'),
('83','183.58.75.131','test666','1491581901'),
('84','122.243.148.204','123456','1491582118'),
('85','122.243.217.183','123456','1491582161'),
('86','183.58.75.131','test666','1491582165'),
('87','183.58.75.131','test666','1491582800'),
('88','183.58.75.131','test666','1491582913'),
('89','183.58.75.131','test666','1491583860'),
('90','112.17.238.59','123456','1491584090'),
('91','112.17.238.59','123456','1491584294'),
('92','183.58.74.242','test666','1491584617'),
('93','112.17.238.59','123456','1491617952'),
('94','112.17.238.59','123456','1491618864'),
('95','218.15.119.162','test666','1491619721'),
('96','112.12.76.131','123456','1491624985'),
('97','112.12.76.131','123456','1491625218'),
('98','223.104.64.57','test666','1491625253'),
('99','112.12.76.131','123456','1491625380'),
('100','112.12.76.131','123456','1491639069'),
('101','112.12.76.131','123456','1491641044'),
('102','183.58.74.242','test666','1491641321'),
('103','183.58.74.242','test666','1491641509'),
('104','183.58.74.242','test666','1491641606'),
('105','112.12.76.131','123456','1491645160'),
('106','183.58.74.242','test666','1491649216'),
('107','122.243.148.204','123456','1491660568'),
('108','122.243.217.183','123456','1491661399'),
('109','183.58.74.242','test666','1491665600'),
('110','183.58.74.242','test666','1491665817'),
('111','183.58.74.242','test666','1491671631'),
('112','122.243.217.183','123456','1491671791'),
('113','183.58.74.242','test666','1491675178'),
('114','122.243.148.204','123456','1491705811'),
('115','119.134.237.22','test666','1491706619'),
('116','122.243.148.204','123456','1491710992'),
('117','122.243.148.204','123456','1491711221'),
('118','183.58.74.242','test666','1491712767'),
('119','119.134.237.22','test666','1491722357'),
('120','122.243.217.183','123456','1491729610'),
('121','122.243.217.183','123456','1491732039'),
('122','122.243.217.183','123456','1491732726'),
('123','122.243.217.183','123456','1491733006'),
('124','122.243.148.204','123456','1491736591'),
('125','219.129.167.42','test666','1491741446'),
('126','219.129.167.42','test666','1491745959'),
('127','122.243.217.183','123456','1491752977'),
('128','122.243.217.183','123456','1491753287'),
('129','183.58.74.242','test666','1491754092'),
('130','183.58.74.242','test666','1491754821'),
('131','122.243.148.204','123456','1491756507'),
('132','122.243.148.204','123456','1491757329'),
('133','183.58.74.39','test666','1491759915'),
('134','122.243.148.204','123','1491760213'),
('135','183.58.74.39','test666','1491765175'),
('136','122.243.217.183','123','1491769354'),
('137','112.12.76.131','123','1491788265'),
('138','116.29.164.189','test666','1491801368'),
('139','116.29.164.189','test666','1491802459'),
('140','116.29.164.189','test666','1491815643'),
('141','112.12.76.131','123','1491820893'),
('142','112.12.76.131','123','1491821847');


DROP TABLE IF EXISTS ims_mc_address;
CREATE TABLE `ims_mc_address` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `county` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `add_time` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_mc_article;
CREATE TABLE `ims_mc_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `classify` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `del` tinyint(1) unsigned zerofill DEFAULT '0' COMMENT 'æ˜¯å¦åˆ é™¤',
  `add_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_mc_bank;
CREATE TABLE `ims_mc_bank` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT NULL,
  `bankname` varchar(100) DEFAULT NULL,
  `banknum` varchar(100) DEFAULT NULL,
  `add_time` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_mc_members;
CREATE TABLE `ims_mc_members` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `username` varchar(30) NOT NULL COMMENT 'ç”¨æˆ·å',
  `realname` varchar(16) NOT NULL COMMENT 'çœŸå®žå§“å',
  `mobile` varchar(11) NOT NULL COMMENT 'ç”µè¯å·ç ',
  `password` varchar(200) NOT NULL COMMENT 'å¯†ç ',
  `salt` varchar(10) NOT NULL COMMENT 'ä¸ºå¯†ç åŠ ç›',
  `level` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'ä¼šå‘˜çº§åˆ«',
  `type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(4) unsigned NOT NULL DEFAULT '1',
  `joindate` int(10) unsigned NOT NULL,
  `joinip` varchar(15) NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL,
  `lastip` varchar(15) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_mc_myqr;
CREATE TABLE `ims_mc_myqr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sid` varchar(30) NOT NULL COMMENT 'æ´»ç ID',
  `uid` int(10) unsigned NOT NULL,
  `qrimg` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fazhi` smallint(5) NOT NULL,
  `count` int(10) unsigned DEFAULT '0',
  `del` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'æ˜¯å¦å–æ¶ˆè®¢å•',
  `add_time` int(10) unsigned NOT NULL COMMENT 'åˆ›å»ºæ—¶é—´',
  PRIMARY KEY (`id`),
  UNIQUE KEY `sidå”¯ä¸€` (`sid`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_mc_qr;
CREATE TABLE `ims_mc_qr` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sid` varchar(100) NOT NULL COMMENT 'æ´»ç ID',
  `weight` smallint(5) DEFAULT '0' COMMENT 'æƒé‡',
  `img` varchar(255) DEFAULT NULL COMMENT 'å›¾ç‰‡',
  `count` smallint(5) unsigned DEFAULT '0',
  `del` tinyint(1) unsigned DEFAULT '0' COMMENT 'æçŽ°çŠ¶æ€0:å¤„ç†ä¸­ 1:å·²å¤„ç†',
  `add_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=208 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_pattern;
CREATE TABLE `ims_pattern` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` int(10) unsigned NOT NULL COMMENT 'å•ä»·',
  `amount` double(10,2) unsigned NOT NULL COMMENT 'æ—¶é—´',
  `amount2` double(10,2) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_profile_fields;
CREATE TABLE `ims_profile_fields` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field` varchar(255) NOT NULL,
  `available` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `displayorder` smallint(6) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `unchangeable` tinyint(1) NOT NULL,
  `showinregister` tinyint(1) NOT NULL,
  `field_length` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_rebate;
CREATE TABLE `ims_rebate` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `level` tinyint(2) unsigned NOT NULL COMMENT 'ç­‰çº§',
  `rebate` double(3,2) unsigned NOT NULL COMMENT 'æŠ˜æ‰£',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_record;
CREATE TABLE `ims_record` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL COMMENT 'å–å®¶ç”¨æˆ·',
  `payuid` varchar(30) NOT NULL COMMENT 'ä¹°å…¥ç”¨æˆ·',
  `payamount` double(10,2) unsigned NOT NULL COMMENT 'å–å‡ºæ•°é‡',
  `amount` double(10,2) unsigned NOT NULL COMMENT 'æ€»ä»·æ ¼',
  `getamount` double(10,2) unsigned NOT NULL COMMENT 'ä¹°å®¶èŽ·å¾—æ•°é‡',
  `sxf` double(10,2) unsigned NOT NULL COMMENT 'æ‰‹ç»­è´¹',
  `add_time` int(10) unsigned NOT NULL COMMENT 'ä¸Šæž¶æ—¶é—´',
  `end_time` int(10) unsigned NOT NULL COMMENT 'ä¹°å…¥æ—¶é—´',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT 'çŠ¶æ€',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_site_multi;
CREATE TABLE `ims_site_multi` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `title` varchar(30) NOT NULL,
  `styleid` int(10) unsigned NOT NULL,
  `site_info` text NOT NULL,
  `status` tinyint(3) unsigned NOT NULL,
  `bindhost` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uniacid` (`uniacid`),
  KEY `bindhost` (`bindhost`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO ims_site_multi VALUES 
('1','1','Wynters','1','','1','');


DROP TABLE IF EXISTS ims_site_styles;
CREATE TABLE `ims_site_styles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uniacid` int(10) unsigned NOT NULL,
  `templateid` int(10) unsigned NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO ims_site_styles VALUES 
('1','1','1','WeUi - [Wynters]');


DROP TABLE IF EXISTS ims_site_templates;
CREATE TABLE `ims_site_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `title` varchar(30) NOT NULL,
  `version` varchar(64) NOT NULL,
  `description` varchar(500) NOT NULL,
  `author` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `sections` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO ims_site_templates VALUES 
('1','default','é»˜è®¤æ¨¡æ¿','','WeUi','Wynters','','1','0');


DROP TABLE IF EXISTS ims_users;
CREATE TABLE `ims_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `groupid` int(10) unsigned NOT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(200) NOT NULL,
  `salt` varchar(10) NOT NULL,
  `type` tinyint(3) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL,
  `joindate` int(10) unsigned NOT NULL,
  `joinip` varchar(15) NOT NULL,
  `lastvisit` int(10) unsigned NOT NULL,
  `lastip` varchar(15) NOT NULL,
  `remark` varchar(500) NOT NULL,
  `starttime` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO ims_users VALUES 
('1','0','admin','87346c4fb914a88060888da717cb33accb2d88a7','47961510','0','0','1490190774','','1491831246','14.144.127.145','','0','0');


DROP TABLE IF EXISTS ims_users_failed_login;
CREATE TABLE `ims_users_failed_login` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip` varchar(15) NOT NULL,
  `username` varchar(32) NOT NULL,
  `count` tinyint(1) unsigned NOT NULL,
  `lastupdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_username` (`ip`,`username`)
) ENGINE=MyISAM AUTO_INCREMENT=243 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_users_group;
CREATE TABLE `ims_users_group` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `package` varchar(5000) NOT NULL,
  `maxaccount` int(10) unsigned NOT NULL,
  `maxsubaccount` int(10) unsigned NOT NULL,
  `timelimit` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS ims_users_profile;
CREATE TABLE `ims_users_profile` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `createtime` int(10) unsigned NOT NULL,
  `realname` varchar(10) NOT NULL,
  `nickname` varchar(20) NOT NULL,
  `avatar` varchar(100) NOT NULL,
  `qq` varchar(15) NOT NULL,
  `mobile` varchar(11) NOT NULL,
  `fakeid` varchar(30) NOT NULL,
  `vip` tinyint(3) unsigned NOT NULL,
  `gender` tinyint(1) NOT NULL,
  `birthyear` smallint(6) unsigned NOT NULL,
  `birthmonth` tinyint(3) unsigned NOT NULL,
  `birthday` tinyint(3) unsigned NOT NULL,
  `constellation` varchar(10) NOT NULL,
  `zodiac` varchar(5) NOT NULL,
  `telephone` varchar(15) NOT NULL,
  `idcard` varchar(30) NOT NULL,
  `studentid` varchar(50) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  `zipcode` varchar(10) NOT NULL,
  `nationality` varchar(30) NOT NULL,
  `resideprovince` varchar(30) NOT NULL,
  `residecity` varchar(30) NOT NULL,
  `residedist` varchar(30) NOT NULL,
  `graduateschool` varchar(50) NOT NULL,
  `company` varchar(50) NOT NULL,
  `education` varchar(10) NOT NULL,
  `occupation` varchar(30) NOT NULL,
  `position` varchar(30) NOT NULL,
  `revenue` varchar(10) NOT NULL,
  `affectivestatus` varchar(30) NOT NULL,
  `lookingfor` varchar(255) NOT NULL,
  `bloodtype` varchar(5) NOT NULL,
  `height` varchar(5) NOT NULL,
  `weight` varchar(5) NOT NULL,
  `alipay` varchar(30) NOT NULL,
  `msn` varchar(30) NOT NULL,
  `email` varchar(50) NOT NULL,
  `taobao` varchar(30) NOT NULL,
  `site` varchar(30) NOT NULL,
  `bio` text NOT NULL,
  `interest` text NOT NULL,
  `workerid` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;



----WeEngine MySQL Dump End