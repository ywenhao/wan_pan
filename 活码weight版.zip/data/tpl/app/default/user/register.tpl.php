<?php defined('IN_IA') or exit('Access Denied');?><?php  $_W['page']['title'] = '用户注册'?>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/header-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/header-yunma', TEMPLATE_INCLUDEPATH));?>
<title>用户注册</title>
<div class="center">
<div class="weui_btn_default weui-header weui_btn_plain_primary"> 
  <div class="weui-header-left"> <a class="icon icon-109 f-green" href="javascript:history.go(-1)">返回</a></div>
   <h1 class="weui-header-title f-green">用户注册</h1>
    </div>
<div style="margin-top: 10px;">
<div class="weui-weixin-img"><!--图片开始-->
    <img src="<?php  echo $_W['attachurl'].$yunma['logo']?>">
</div>

<form class="form-inline" action="" method="post" role="form" id="form1" onsubmit="return formcheck();">

<div class="weui_cells weui_cells_form">
            <div class="weui_cell">
                <div class="weui_cell_hd"><label class="weui_label">用户名</label></div>
                <span class="icon icon-100"></span>
                <div class="weui_cell_bd weui_cell_primary">
                    <input id="username" name="data[username]" class="weui_input" type="user"  placeholder="注册的用户名"/>
                </div>
            </div>
            
            <div class="weui_cell">
                <div class="weui_cell_hd"><label class="weui_label">密码</label></div>
                <span class="icon icon-31"></span>
                <div class="weui_cell_bd weui_cell_primary">
                    <input id="input1" name="data[password]" class="weui_input" type="password" placeholder="注册的密码"/>
                </div>
            </div>
            
     <div class="weui_cell">
                <div class="weui_cell_hd"><label class="weui_label">确认密码</label></div>
                <span class="icon icon-31"></span>
                <div class="weui_cell_bd weui_cell_primary">
                    <input id="input2"  name="password" class="weui_input" type="password" placeholder="核对注册的密码"/>
                </div>
       </div>







       <input name="token" value="<?php  echo $_W['token'];?>" type="hidden" />
<input type="submit" id="submit" style="width: 70%" name="register" class="weui_btn bg-orange-b" value="我要注册">
</form>

<a class="weui_btn bg-blue-b" style="width: 70%" href="<?php  echo url('user/login');?>">我要登录</a>
<div style="margin-top: 20px"></div>
</div>
<script type="text/javascript">
  

$('#submit').click(function(){
  var username = $('#username').val();if(username == ''){$.toast("请输入要注册的用户名", "cancel"); return false;}
  var password = $('#input1').val();if(password == ''){$.toast("请输入密码", "cancel");return false;}
  var password = $('#input2').val();if(password == ''){$.toast("请核对输入密码", "cancel");return false;}
});

</script>
<?php (!empty($this) && $this instanceof WeModuleSite || 0) ? (include $this->template('common/footer-yunma', TEMPLATE_INCLUDEPATH)) : (include template('common/footer-yunma', TEMPLATE_INCLUDEPATH));?>
