<?php
/**
 * 主页
 */
defined('IN_IA') or exit('Access Denied');
define('IN_GW', true);

$op = $_GPC['op'];
$uid = $_W['user']['uid'];
$imgData = $_GPC['imgdata'];
$nameData = $_GPC['namedata'];
load()->model('member');

$Name = $_GPC['Name'];
$FaZhi = $_GPC['FaZhi'];
$qrCode = $_GPC['qrCode'];
$codeId = $_GPC['codeId'];

if (empty($uid))
		die('操你妈，想 FuckSite ? 滚');

if($op == 'create'){

if(empty($_GPC['Name']))
		die(json_encode(array('s' => 'no', 'msg' =>'名称不能为空')));
	elseif(empty($_GPC['FaZhi']))
        die(json_encode(array('s' => 'no', 'msg' =>'阀值不能为空')));
	elseif(empty($_GPC['qrCode']))
        die(json_encode(array('s' => 'no', 'msg' =>'活码不存在<br/>请重新创建')));

//获取活码
	  $QrArr = explode(',',$qrCode);
 	  $QrUrl ='/attachment/images/yunma/'.$uid.'-1-'.time().'.jpg';
	  $imgQr = base64_decode($QrArr[1]);
	  file_put_contents(IA_ROOT.$QrUrl,$imgQr);
	  mc_addQr(array('uid'=>$uid,'sid'=>$codeId,'name'=>$Name,'fazhi'=>$FaZhi,'qrimg'=>$QrUrl));
if(!empty($imgData)){
for ($i=0; $i < count($imgData); $i++) { 

	  $imgArr = explode(',',$imgData[$i]);
	  $imgUrl = '/attachment/images/yunma/'.$uid.'-2-'.time().'-'.$i.'.jpg';
	  $imgStr = base64_decode($imgArr[1]);
	  $nameStr = $nameData[$i];
	  file_put_contents(IA_ROOT.$imgUrl,$imgStr);
	  mc_addQrSon(array('sid'=>$codeId,'img'=>$imgUrl,'i_name'=>$nameStr));
}
}
die(json_encode(array('s' => 'ok', 'msg' =>'创建成功')));
}elseif($op == 'edit'){
	
if(empty($_GPC['Name']))
		die(json_encode(array('s' => 'no', 'msg' =>'名称不能为空')));
	elseif(empty($_GPC['FaZhi']))
        die(json_encode(array('s' => 'no', 'msg' =>'阀值不能为空')));
	elseif(empty($_GPC['qrCode']))
        die(json_encode(array('s' => 'no', 'msg' =>'活码不存在<br/>请重新创建')));

	  mc_updateQr(array('name'=>$Name,'fazhi'=>$FaZhi),$codeId);
if(!empty($imgData)){
	for ($i=0; $i < count($imgData); $i++) {

	  $imgArr = explode(',',$imgData[$i]);
	  $imgUrl = '/attachment/images/yunma/'.$uid.'-2-'.time().'-'.$i.'.jpg';
	  $imgStr = base64_decode($imgArr[1]);
	  $nameStr = $nameData[$i];
	  file_put_contents(IA_ROOT.$imgUrl,$imgStr);
	  mc_addQrSon(array('sid'=>$codeId,'img'=>$imgUrl,'i_name'=>$nameStr));
	}
}
die(json_encode(array('s' => 'ok', 'msg' =>'修改成功')));
}